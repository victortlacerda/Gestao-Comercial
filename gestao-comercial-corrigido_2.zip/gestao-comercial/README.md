# Gestão Comercial — Sammour Engenharia

App de acompanhamento comercial que substitui a planilha: funil de vendas, dashboards, classificação de propostas e cobrança de contatos da equipe. Roda no navegador do computador e do celular, sem servidor e sem instalação.

---

## O que tem dentro

| Tela | Para que serve |
|---|---|
| **Painel** | KPIs (valor em aberto, valor fechado, conversão, ticket médio, meta do mês), funil, propostas por mês, valor por estado (alternando entre cotado e fechado), serviços mais cotados, maiores oportunidades e melhores clientes. |
| **Funil** | Quadro por etapa (Nova → Enviada → Em negociação → Aguardando retorno → Fechada / Perdida). No computador, arraste o cartão para mudar o status. |
| **Propostas** | Base completa com busca, filtros (status, classificação, UF, vendedor), ordenação por coluna, tempo parado em cada etapa, seleção múltipla para trocar status ou **excluir várias de uma vez** e exportação em CSV. |
| **Follow-up** | Agenda do dia: o que está marcado para hoje, o que venceu e o que passou do prazo sem contato. Botões "Ligação hoje" e "Reunião hoje" e contador "exibindo X de Y" ao final da lista. |
| **Relatório** | Uma página por semana (segunda a domingo) para a reunião: fechadas, perdidas com motivo, propostas novas, esforço por vendedor e a agenda dos próximos dias. Botão de imprimir/salvar em PDF e **exportar a planilha de obras fechadas** (ver abaixo). |
| **Equipe** | Ligações, reuniões e outros contatos por vendedor no período, propostas sem contato e valor fechado. |
| **Importar** | Planilha .xlsm/.xlsx, leitura de PDFs, backup e exportação para Excel. |
| **Ajustes** | Metas do mês, prazo de follow-up e cadastro dos vendedores. |

Classificação de proposta: **Boa / Regular / Ruim** (vem do campo "Probabilidade" da planilha atual).

**Próximo contato.** Cada proposta aberta tem o campo *Próximo contato em*, com atalhos de +1 dia, +1 semana e +15 dias. Ao registrar um contato na data marcada ou depois, a marcação é baixada sozinha. Fechar ou perder a proposta também a tira da agenda.

**Motivo da perda.** Ao mudar o status para Perdida, o app pede o motivo (Preço, Prazo, Concorrente, Obra cancelada, Sem retorno, Outro) — no detalhe da proposta, na barra de seleção múltipla e ao arrastar o cartão para a coluna Perdida no funil. É o que alimenta a seção de perdas do relatório.

Serviço é escolhido em lista fixa: **PIT, PDA, PCE CONVENCIONAL, PCE HELICOIDAL, PLACA, PROJETO DE FUNDAÇÕES, PROJETO DE CONTENÇÕES, CONSULTORIA, ATP**. Valores diferentes que vieram da planilha continuam aparecendo na lista da proposta em que estão, e a opção *Outro (digitar)…* abre um campo livre para um caso fora do padrão.

**Registro de contato com data e hora.** Ao abrir uma proposta, a seção *Registrar contato* traz os campos **Data do contato** e **Horário** já preenchidos com o momento atual. Basta ajustar antes de clicar no tipo (Ligação, Reunião, E-mail...) para lançar um atendimento que aconteceu antes — útil para recuperar o histórico. Datas futuras não são aceitas. Os botões "Ligação hoje" e "Reunião hoje" da tela **Follow-up** continuam registrando no momento do clique.

Contatos gravados antes desta versão continuam valendo; ficam apenas sem horário e são ordenados no fim do dia.

**Como a proposta anda no funil.** Na importação da planilha, o status vem da coluna Status e, quando ela está vazia, de *Proposta Enviada* (`Sim` → Enviada). Propostas lidas de PDF entram como **Nova** — para movê-las, marque as caixas em Propostas e use *Aplicar status → Enviada*; dá para selecionar todas as filtradas de uma vez pelo cabeçalho. Reimportar um PDF nunca desfaz o status que o comercial já definiu.

Cada mudança de etapa grava a data, então o app mostra há quantos dias a proposta está parada — no cartão do funil, na coluna "Na etapa", na média por etapa do painel e no histórico dentro do detalhe. Para as propostas que vieram da planilha, a contagem começa na data de emissão, já que não havia esse registro antes.

---

## Planilha de obras fechadas

Na tela **Relatório**, ao lado do botão de imprimir, escolha o recorte e clique em **⭳ Exportar obras fechadas (Excel)**. Sai um `.xlsx` com sete abas:

| Aba | O que traz |
|---|---|
| **RESUMO** | Período, vendedor, quantidade de obras, valor total, ticket médio e a contagem de cada tipo de serviço. |
| **OBRAS FECHADAS** | Uma linha por obra: contrato, cliente, obra, cidade, UF, valor, quantidade de serviços, **uma coluna para cada serviço** (1 = tem, 0 = não tem), datas de proposta e fechamento, dias até fechar, vendedor, classificação, CNPJ, contato, telefone, e-mail, ligações, reuniões e observações. |
| **POR SERVIÇO** | Uma linha para cada serviço de cada obra — o formato certo para tabela dinâmica. |
| **RESUMO SERVIÇOS** | Quantas obras fechadas incluem cada serviço, o percentual e o valor. |
| **POR CIDADE** / **POR CLIENTE** / **POR VENDEDOR** | Obras, valor total, ticket médio e os serviços de cada agrupamento. |

Recortes disponíveis no seletor ao lado do botão: **período do filtro** (o do topo da tela, pela data da proposta), **semana do relatório** (pela data em que a proposta foi marcada como Fechada) ou **todas as obras fechadas** da base. O filtro de vendedor do relatório também vale para a planilha.

Como uma obra pode ter mais de um serviço, o valor aparece de duas formas: *Valor das obras* soma o valor cheio de toda obra que inclui aquele serviço (útil para "quanto de PIT passou pela empresa") e *Valor rateado* divide o valor da obra entre os serviços dela, de modo que a soma da coluna bate com o total geral. A data de fechamento vem do histórico de etapas; nas propostas antigas importadas da planilha, cai na data de emissão.

---

## Publicar no GitHub Pages

1. Crie um repositório novo (pode ser público) — por exemplo `gestao-comercial`.
2. Envie **todo o conteúdo desta pasta** (`index.html`, `assets/`, `manifest.webmanifest`).
3. No repositório: **Settings → Pages → Source: Deploy from a branch → Branch: `main` / `(root)` → Save**.
4. Em cerca de um minuto o app fica em `https://SEU-USUARIO.github.io/gestao-comercial/`.
5. No celular, abra o endereço e use **Adicionar à tela de início** — vira um atalho com cara de aplicativo.

Existe também o arquivo **`app-arquivo-unico.html`**: é o app inteiro em um arquivo só. Serve para testar rápido (basta abrir com duplo clique) ou para enviar por e-mail/WhatsApp para alguém usar sem GitHub.

---

**Filtro de período** (topo de todas as telas): todo o período, últimos 7 / 30 / 90 dias e um item por ano encontrado na base — *2026 (484)*, *2025 (…)* — com a quantidade de propostas ao lado. Os anos saem da data de cada proposta, que o app deduz do número do contrato (`050126-001` → 05/01/2026). Quando o contrato não segue esse padrão, a data vem da coluna de semana da planilha, e aí o ano assumido é o da importação — vale conferir essas propostas antes de tirar conclusão de um ano antigo.

## Primeiro uso

1. Abra o app → aba **Importar**.
2. **1. Importar a planilha atual**: escolha o `Gestão_Comercial_2026_-_Sammour_Engenharia.xlsm`. O app lê a aba PROPOSTAS e converte cada linha (na base atual: 484 propostas, R$ 29,5 mi cotados, 105 fechadas).
3. **Ajustes**: cadastre os vendedores e defina metas e o prazo de follow-up (padrão: 15 dias).
4. Em **Propostas**, abra cada uma e defina o vendedor responsável — é isso que alimenta a tela **Equipe**.

Como a planilha original não traz o histórico de ligações e reuniões, esse histórico começa a partir do primeiro contato registrado no app.

---

## Alimentar com os PDFs das propostas

**Pelo próprio app (mais simples).** Importar → *2. Ler PDFs das propostas*:

- **PDFs avulsos** — funciona no celular e no computador.
- **Pasta de propostas** — só em navegador de computador (Chrome, Edge). Além do PDF, aproveita o nome da pasta no padrão `Proposta 145 - CLIENTE - CIDADE - SERVIÇO` para preencher cliente, cidade e serviço.

**Qual PDF é lido.** O app reconhece o padrão `Proposta - DDMMAA - Número - CLIENTE - SERVIÇO`, com `- Rev.01` quando há revisão. Em cada pasta ele lê **um arquivo só: a revisão mais recente**. Revisões contam como a mesma proposta (mesmo código de contrato), então o total do ano não infla. Anexos como ART, memorial e contrato são ignorados; se a pasta não tiver nenhum arquivo no padrão, o app lê o primeiro PDF para não perder a proposta e avisa no registro.

Dentro do PDF ele procura, nas 10 primeiras páginas: número da proposta, CNPJ, `A/C:`, `Tel.:`, `E-mail:`, `Obra:` e o `Valor total:` da tabela de preços. Quando a obra termina em `Cidade/UF`, cidade e estado também são preenchidos. Tudo é lido no próprio navegador — nenhum arquivo sai do computador.

**Em lote, pelo Python** (centenas de pastas de uma vez), use o script incluído:

```bash
pip install pymupdf pandas openpyxl
python extrator/extrator_propostas.py "C:/Propostas 2026"
```

Ele gera `propostas_AAAAMMDD_HHMM.json`. No app: Importar → **Carregar propostas.json**.

Quando uma proposta importada já existe (mesmo número de contrato), os dados do PDF atualizam os campos cadastrais, mas **status, classificação, vendedor e observações que você editou são preservados**.

---

## Temperatura (Quente / Morno / Frio)

Classificação separada da que já existia. As duas medem coisas diferentes e
convivem no mesmo cartão:

- **Classificação** (Boa / Regular / Ruim) — a qualidade da oportunidade, vinda
  da coluna *Probabilidade* da planilha.
- **Temperatura** (Quente / Morno / Frio) — o quanto está perto de decidir.

Uma obra pode ser Boa e Fria (vale muito, mas parou) ou Ruim e Quente (fecha
essa semana, vale pouco). É essa combinação que orienta o follow-up.

Onde aparece e como se mexe:

- **Follow-up** — selo ao lado do status e filtro próprio na barra, incluindo a
  opção *Sem temperatura definida*, que é a fila de triagem.
- **Funil** — selo ao lado de Boa/Regular/Ruim, no topo do cartão.
- **Propostas** — selo na coluna Classificação, filtro na barra e ordenação
  (*Quentes primeiro*).
- **Ficha da proposta** e **cadastro de nova proposta** — campo de edição.
- **Em lote** — selecione várias na tela Propostas e use *Aplicar temperatura*.
  É o caminho prático para classificar uma base grande sem abrir uma a uma.

Propostas importadas entram **sem temperatura** — o campo fica vazio até alguém
decidir, em vez de inventar um valor. O selo só é desenhado quando há valor, e
sai nas exportações CSV e de obras fechadas. Se um dia a planilha ganhar uma
coluna *Temperatura*, a importação já a reconhece (aceita "quente", "MORNO",
"frio" em qualquer caixa) e ela é preservada nas reimportações, como o status e
o vendedor.

## Ordenação da lista de propostas

A tela **Propostas** abre ordenada pelo sequencial do contrato (os três últimos
dígitos de `ddmmaa-nnn`), da mais recente para a mais antiga. Como o sequencial é
emitido em ordem, isso equivale à ordem cronológica sem depender da data.

Duas formas de mudar, com o mesmo resultado:

- **Clicando no cabeçalho da tabela** — qualquer coluna. Um clique ordena, outro
  inverte. A coluna ativa fica em negrito com uma seta ▲/▼. Funciona também pelo
  teclado (Tab + Enter).
- **Pelo seletor da barra de filtros** — é o único caminho no celular, onde a
  lista vira cards e não há cabeçalho para clicar.

Colunas sem opção equivalente no seletor (serviço, classificação, status) são
ordenadas só pelo cabeçalho; nesses casos o seletor fica sem marcação. O contador
acima da tabela sempre diz qual é a ordem em vigor.

Em qualquer critério, o empate é desfeito pelo número da proposta, da maior para
a menor — então a ordem nunca "dança" entre um render e outro. Classificação
ordena por qualidade (Boa → Regular → Ruim) e status segue a ordem do funil, não
o alfabeto. Texto ignora acento: ÁGUAS aparece junto de AGUAS.

## Como a semana da planilha vira data

A planilha comercial trabalha com rótulos do tipo `MAI - SEM 04`. A regra usada
na importação, conferida contra as 499 linhas da base de 2026 (as datas embutidas
no número do contrato bateram 499/499):

> **SEM n é a semana que começa na n-ésima segunda-feira do mês.**

Cada rótulo vira a segunda-feira daquela semana. Como o relatório fecha de segunda
a domingo, isso basta para o registro cair na semana certa mesmo sem o dia exato:

| Rótulo | Data gravada |
|---|---|
| `JAN - SEM 01` | 05/01/26 |
| `MAI - SEM 04` | 25/05/26 |
| `AGO - SEM 01` | 03/08/26 |

`SEM 05` em mês com só quatro segundas cai na última semana do próprio mês.
Fechamento com mês anterior ao da proposta é lido como ano seguinte (proposta em
DEZ, fechada em JAN), e o fechamento nunca fica antes da emissão.

Nas exportações de obras fechadas há a coluna **Semana de fechamento**, que faz o
caminho de volta e devolve o rótulo no formato da planilha.

### Correções da versão 2 da base

- A etapa "Fechada" era gravada com a **data da importação**, não com a semana de
  fechamento da planilha. Obras antigas apareciam como fechadas na semana da
  reunião. O histórico agora usa a data do fato, e a base v1 é corrigida
  sozinha na primeira abertura.
- A mesclagem usava só o número do contrato como chave. Contrato repetido com
  cliente diferente sobrescrevia a proposta anterior em silêncio. A chave passou
  a ser contrato + cliente, e as repetições aparecem no log da importação.
- Toda data era exibida um dia atrasada: `new Date('2026-08-17')` é meia-noite em
  UTC, que no Brasil cai no dia 16. As datas passam a ser lidas ao meio-dia local.

## Onde os dados ficam

No armazenamento local do navegador, naquele dispositivo. Não há servidor, então:

- A exclusão em lote (tela **Propostas**) pede confirmação mostrando quantas propostas, os primeiros clientes e o valor somado — mas não tem desfazer. Exporte o backup antes de uma limpeza grande.
- **Exporte o backup** (Importar → *Exportar backup .json*) com frequência e guarde no Drive/OneDrive da empresa.
- Para levar a base para outro celular ou computador: exporte no primeiro, restaure no segundo.
- Limpar dados de navegação com "cookies e dados de sites" apaga a base — o backup é a proteção.
- Cada pessoa que abrir o link começa com a base vazia até restaurar um backup. Nesse estado o app mostra um aviso amarelo no topo: sem propostas, não há indicadores, gráficos nem anos no filtro de período.
- Os arquivos são carregados com `?v=` no endereço. Ao publicar uma versão nova no GitHub Pages, troque esse número em `index.html` (ou rode o build) para o navegador não continuar usando os arquivos antigos do cache.

Se a equipe precisar ver e editar a **mesma base ao mesmo tempo**, aí é preciso um banco de dados online (Supabase e Firebase têm plano gratuito e conversam bem com este código, sem trocar de tecnologia). O app foi escrito com essa troca em mente: toda a leitura e gravação está isolada em `assets/js/store.js`.

---

## Estrutura dos arquivos

```
index.html                  estrutura das telas
manifest.webmanifest        atalho na tela de início do celular
app-arquivo-unico.html      o app inteiro em um arquivo (cópia gerada)
assets/css/styles.css       identidade visual (azul claro e branco)
assets/js/store.js          dados, regras e cálculos dos indicadores
assets/js/importers.js      planilha, PDFs, backup e exportações
assets/js/charts.js         gráficos
assets/js/app.js            telas e interações
extrator/extrator_propostas.py   leitura em lote das pastas de propostas
build-arquivo-unico.py      regera o app-arquivo-unico.html a partir dos arquivos acima
```

Depois de mexer no CSS ou nos JS, rode `python build-arquivo-unico.py` para o arquivo único ficar igual à versão em pastas.

Bibliotecas carregadas por CDN: Chart.js (gráficos), SheetJS (Excel) e PDF.js (leitura de PDF). É preciso internet na primeira abertura.

---

## Ajustes rápidos que você pode fazer sozinho

- **Cores**: `assets/css/styles.css`, bloco `:root` no topo (`--brand` é o azul principal).
- **Etapas do funil**: `assets/js/store.js`, constante `STATUS`.
- **Tipos de contato** (ligação, reunião...): `assets/js/store.js`, constante `TIPOS_ATIVIDADE`.
- **Motivos de perda**: `assets/js/store.js`, constante `MOTIVOS_PERDA`.
- **Lista de serviços**: `assets/js/store.js`, constante `SERVICOS` (a lista `SERVICOS_LEGADO` ao lado só serve para os gráficos entenderem os nomes antigos da planilha).
- **O que o app procura no PDF**: `assets/js/importers.js`, objeto `PADROES`.
- **Padrão do nome do arquivo e revisões**: `assets/js/importers.js`, função `analisarNomeArquivo`.
