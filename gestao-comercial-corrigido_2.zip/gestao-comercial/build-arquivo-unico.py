#!/usr/bin/env python3
"""Regenera app-arquivo-unico.html juntando index.html, o CSS e os JS.

Uso:  python build-arquivo-unico.py
"""
import pathlib
import re

raiz = pathlib.Path(__file__).parent
html = (raiz / 'index.html').read_text(encoding='utf-8')
css = (raiz / 'assets/css/styles.css').read_text(encoding='utf-8')
js = [
    (raiz / 'assets/js/store.js').read_text(encoding='utf-8'),
    (raiz / 'assets/js/importers.js').read_text(encoding='utf-8'),
    (raiz / 'assets/js/charts.js').read_text(encoding='utf-8'),
    (raiz / 'assets/js/app.js').read_text(encoding='utf-8'),
]

# sem manifest (arquivo único não tem a pasta do lado)
html = re.sub(r'\s*<link rel="manifest"[^>]*>\n', '\n', html)
# CSS externo -> <style> embutido
html = re.sub(r'<link rel="stylesheet" href="assets/css/styles\.css[^"]*"[^>]*>',
              '<style>\n' + css + '\n</style>', html)
# JS externos -> blocos <script> embutidos
blocos = '\n'.join('<script defer>\n' + t + '\n</script>' for t in js)
html = re.sub(r'<script src="assets/js/[^"]+"\s*defer></script>\n?', '', html)
html = html.replace('</body>', blocos + '\n</body>')

(raiz / 'app-arquivo-unico.html').write_text(html, encoding='utf-8')
print('app-arquivo-unico.html regenerado.')
