/* ===========================================================
   charts.js — gráficos do painel (Chart.js)
   =========================================================== */
(function () {
  'use strict';

  var S = window.Store;
  var instancias = {};
  var AZUL = '#1E73D3', AZUL_CLARO = '#8FC0F2', AZUL_SUAVE = '#D7E9FC';
  var VERDE = '#10996B', AMARELO = '#E0A63A', VERMELHO = '#D64545';
  var MESES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

  function base() {
    if (!window.Chart) return;
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.font.size = 12;
    Chart.defaults.color = '#5B7590';
    Chart.defaults.plugins.legend.labels.boxWidth = 10;
    Chart.defaults.plugins.legend.labels.boxHeight = 10;
    Chart.defaults.plugins.legend.labels.usePointStyle = true;
    Chart.defaults.maintainAspectRatio = false;
  }

  function desenhar(canvasId, config) {
    if (!window.Chart) return;
    var el = document.getElementById(canvasId);
    if (!el) return;
    if (instancias[canvasId]) instancias[canvasId].destroy();
    instancias[canvasId] = new Chart(el.getContext('2d'), config);
  }

  var eixoLimpo = {
    grid: { color: '#EDF3FA', drawBorder: false },
    ticks: { padding: 6 },
    border: { display: false }
  };

  function porMes(lista) {
    var dados = S.porMes(lista);
    desenhar('ch-mes', {
      type: 'bar',
      data: {
        labels: MESES,
        datasets: [
          { label: 'Propostas enviadas', data: dados.map(function (m) { return m.enviadas; }), backgroundColor: AZUL_CLARO, borderRadius: 5, yAxisID: 'y', order: 2 },
          { label: 'Propostas fechadas', data: dados.map(function (m) { return m.fechadas; }), backgroundColor: AZUL, borderRadius: 5, yAxisID: 'y', order: 2 },
          {
            label: 'Valor fechado', type: 'line', data: dados.map(function (m) { return m.valorFechado; }),
            borderColor: VERDE, backgroundColor: VERDE, tension: .35, yAxisID: 'y1', pointRadius: 3, borderWidth: 2, order: 1
          }
        ]
      },
      options: {
        interaction: { mode: 'index', intersect: false },
        scales: {
          x: { grid: { display: false }, border: { display: false } },
          y: Object.assign({ beginAtZero: true, title: { display: false } }, eixoLimpo),
          y1: {
            position: 'right', beginAtZero: true, grid: { display: false }, border: { display: false },
            ticks: { callback: function (v) { return S.moedaCurta(v); } }
          }
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: function (c) {
                if (c.dataset.yAxisID === 'y1') return c.dataset.label + ': ' + S.moeda(c.parsed.y);
                return c.dataset.label + ': ' + c.parsed.y;
              }
            }
          }
        }
      }
    });
  }

  function classificacao(res) {
    desenhar('ch-classificacao', {
      type: 'doughnut',
      data: {
        labels: ['Boa', 'Regular', 'Ruim'],
        datasets: [{
          data: [res.boas, res.regulares, res.ruins],
          backgroundColor: [VERDE, AMARELO, VERMELHO],
          borderWidth: 3, borderColor: '#fff', hoverOffset: 6
        }]
      },
      options: {
        cutout: '62%',
        plugins: {
          legend: { position: 'bottom' },
          tooltip: {
            callbacks: {
              label: function (c) {
                var total = c.dataset.data.reduce(function (a, b) { return a + b; }, 0) || 1;
                return c.label + ': ' + c.parsed + ' (' + Math.round(c.parsed / total * 100) + '%)';
              }
            }
          }
        }
      }
    });
  }

  /** modo: 'cotado' (todas as propostas) ou 'fechado' (somente status Fechada). */
  function porEstado(lista, modo) {
    var fechado = modo === 'fechado';
    var base = fechado ? lista.filter(function (p) { return p.status === 'Fechada'; }) : lista;
    var grupos = S.agruparPor(base, 'estado').slice(0, 8);

    var canvas = document.getElementById('ch-estado');
    var vazio = document.getElementById('ch-estado-vazio');
    if (vazio && canvas) {
      var semDados = !grupos.length;
      vazio.hidden = !semDados;
      canvas.style.display = semDados ? 'none' : '';
      vazio.textContent = fechado
        ? 'Nenhuma proposta fechada no período selecionado.'
        : 'Nenhuma proposta no período selecionado.';
      if (semDados) {
        if (instancias['ch-estado']) { instancias['ch-estado'].destroy(); delete instancias['ch-estado']; }
        return;
      }
    }

    desenhar('ch-estado', {
      type: 'bar',
      data: {
        labels: grupos.map(function (g) { return g.chave; }),
        datasets: [{
          label: fechado ? 'Valor fechado' : 'Valor cotado', data: grupos.map(function (g) { return g.valor; }),
          backgroundColor: AZUL, borderRadius: 5, barThickness: 18
        }]
      },
      options: {
        indexAxis: 'y',
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: function (c) {
                var g = grupos[c.dataIndex];
                return S.moeda(g.valor) + ' — ' + g.qtd + (fechado ? ' fechada(s)' : ' proposta(s)');
              }
            }
          }
        },
        scales: {
          x: Object.assign({ beginAtZero: true, ticks: { callback: function (v) { return S.moedaCurta(v); } } }, eixoLimpo),
          y: { grid: { display: false }, border: { display: false } }
        }
      }
    });
  }

  /** Quantidade (barra) e valor cotado (linha): PIT é volume, projeto é ticket. */
  function porServico(lista) {
    var dados = {};
    lista.forEach(function (p) {
      var servicos = S.servicos(p);
      if (!servicos.length) return;
      /* propostas com mais de um serviço rateiam o valor, senão o total infla */
      var fatia = S.numero(p.valor) / servicos.length;
      servicos.forEach(function (s) {
        if (!dados[s]) dados[s] = { qtd: 0, valor: 0 };
        dados[s].qtd++;
        dados[s].valor += fatia;
      });
    });
    var pares = Object.keys(dados).map(function (k) { return { nome: k, qtd: dados[k].qtd, valor: dados[k].valor }; })
      .sort(function (a, b) { return b.valor - a.valor; }).slice(0, 8);

    desenhar('ch-servico', {
      type: 'bar',
      data: {
        labels: pares.map(function (p) { return p.nome; }),
        datasets: [
          { label: 'Propostas', data: pares.map(function (p) { return p.qtd; }), backgroundColor: AZUL_CLARO, borderRadius: 5, yAxisID: 'y', order: 2 },
          {
            label: 'Valor cotado', type: 'line', data: pares.map(function (p) { return p.valor; }),
            borderColor: VERDE, backgroundColor: VERDE, tension: .3, pointRadius: 3, borderWidth: 2, yAxisID: 'y1', order: 1
          }
        ]
      },
      options: {
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { position: 'bottom' },
          tooltip: {
            callbacks: {
              label: function (ctx) {
                var d = pares[ctx.dataIndex];
                if (ctx.dataset.type === 'line') {
                  return 'Valor cotado: ' + S.moeda(d.valor) + ' (média ' + S.moeda(d.valor / d.qtd) + ')';
                }
                return 'Propostas: ' + d.qtd;
              }
            }
          }
        },
        scales: {
          x: { grid: { display: false }, border: { display: false } },
          y: Object.assign({ beginAtZero: true, title: { display: true, text: 'propostas' } }, eixoLimpo),
          y1: {
            position: 'right', beginAtZero: true, grid: { display: false }, border: { display: false },
            ticks: { callback: function (v) { return S.moedaCurta(v); } }
          }
        }
      }
    });
  }

  function equipe(lista, vendedores, dias) {
    var corte = new Date(Date.now() - dias * 86400000).toISOString().slice(0, 10);
    var nomes = vendedores.length ? vendedores.slice() : ['Sem vendedor'];
    var tipos = ['Ligação', 'Reunião', 'E-mail', 'WhatsApp', 'Visita'];
    var cores = [AZUL, VERDE, AZUL_CLARO, AMARELO, AZUL_SUAVE];

    var matriz = tipos.map(function () { return nomes.map(function () { return 0; }); });
    lista.forEach(function (p) {
      (p.atividades || []).forEach(function (a) {
        if ((a.data || '') < corte) return;
        var quem = a.responsavel || p.vendedor || 'Sem vendedor';
        var col = nomes.indexOf(quem);
        if (col === -1) { nomes.push(quem); matriz.forEach(function (l) { l.push(0); }); col = nomes.length - 1; }
        var lin = tipos.indexOf(a.tipo);
        if (lin === -1) return;
        matriz[lin][col]++;
      });
    });

    desenhar('ch-equipe', {
      type: 'bar',
      data: {
        labels: nomes,
        datasets: tipos.map(function (t, i) {
          return { label: t, data: matriz[i], backgroundColor: cores[i], borderRadius: 4, stack: 'a' };
        })
      },
      options: {
        plugins: { legend: { position: 'bottom' } },
        scales: {
          x: { stacked: true, grid: { display: false }, border: { display: false } },
          y: Object.assign({ stacked: true, beginAtZero: true }, eixoLimpo)
        }
      }
    });
  }

  window.Charts = { base: base, porMes: porMes, classificacao: classificacao, porEstado: porEstado, porServico: porServico, equipe: equipe };
})();
