/* ===========================================================
   store.js — estado, persistência e regras de negócio
   =========================================================== */
(function () {
  'use strict';

  var CHAVE = 'sammour_gestao_comercial_v1';

  var STATUS = ['Nova', 'Enviada', 'Em negociação', 'Aguardando retorno', 'Fechada', 'Perdida'];
  var STATUS_ABERTOS = ['Nova', 'Enviada', 'Em negociação', 'Aguardando retorno'];
  var CLASSIFICACOES = ['Boa', 'Regular', 'Ruim'];
  /* Temperatura = quão perto de decidir. Convive com a classificação (Boa/
     Regular/Ruim), que é a qualidade da oportunidade: uma obra pode ser Boa e
     Fria (vale muito, mas está parada) ou Ruim e Quente (fecha já, vale pouco). */
  var TEMPERATURAS = ['Quente', 'Morno', 'Frio'];
  var TIPOS_CLIENTE = ['NOVO', 'ANTIGO'];
  var TIPOS_ATIVIDADE = ['Ligação', 'Reunião', 'E-mail', 'WhatsApp', 'Visita', 'Outro'];
  var SERVICOS = [
    'PIT', 'PDA', 'PCE CONVENCIONAL', 'PCE HELICOIDAL', 'PLACA',
    'PROJETO DE FUNDAÇÕES', 'PROJETO DE CONTENÇÕES', 'CONSULTORIA', 'ATP'
  ];
  var MOTIVOS_PERDA = ['Preço', 'Prazo', 'Concorrente', 'Obra cancelada', 'Sem retorno', 'Outro'];
  /* termos antigos que ainda aparecem na base importada da planilha */
  var SERVICOS_LEGADO = ['PCE', 'PROJETO', 'PCT'];

  var padrao = {
    propostas: [],
    vendedores: ['Comercial 1', 'Comercial 2'],
    config: { metaPropostas: 60, metaValor: 500000, diasFollowup: 15 },
    versao: 2
  };

  var VERSAO_DADOS = 2;

  /* ---------- persistência (com fallback em memória) ---------- */
  var memoria = null;
  var localOk = true;
  try {
    window.localStorage.setItem('__t', '1');
    window.localStorage.removeItem('__t');
  } catch (e) { localOk = false; }

  function carregar() {
    if (!localOk) return memoria ? clonar(memoria) : clonar(padrao);
    try {
      var bruto = window.localStorage.getItem(CHAVE);
      if (!bruto) return clonar(padrao);
      var dados = JSON.parse(bruto);
      dados.propostas = dados.propostas || [];
      dados.vendedores = dados.vendedores || [];
      dados.config = Object.assign({}, padrao.config, dados.config || {});
      dados.propostas.forEach(function (p) {
        if (!p.historicoStatus || !p.historicoStatus.length) {
          p.historicoStatus = [{ status: p.status || 'Nova', data: dataDoStatus(p) }];
        }
        if (p.revisao == null) p.revisao = 0;
      });
      return migrar(dados);
    } catch (e) {
      console.warn('Falha ao ler os dados salvos:', e);
      return clonar(padrao);
    }
  }

  /**
   * Base v1 gravava a etapa "Fechada" com a data da importação, e não com a
   * semana de fechamento da planilha — o que jogava obras antigas para dentro
   * da semana do relatório. Aqui o histórico é reancorado na data real.
   */
  function migrar(dados) {
    if ((dados.versao || 1) >= VERSAO_DADOS) return dados;
    dados.propostas.forEach(function (p) {
      if (p.status !== 'Fechada' || !p.dataFechamento) return;
      var hist = p.historicoStatus || (p.historicoStatus = []);
      var achou = false;
      hist.forEach(function (h) {
        if (h.status === 'Fechada') { h.data = p.dataFechamento; achou = true; }
      });
      if (!achou) hist.push({ status: 'Fechada', data: p.dataFechamento });
      hist.sort(function (a, b) { return String(a.data || '').localeCompare(String(b.data || '')); });
    });
    dados.versao = VERSAO_DADOS;
    dados.migrou = true;      // sinaliza para gravar a base já corrigida
    return dados;
  }

  function salvar() {
    if (!localOk) { memoria = clonar(estado); return true; }
    try {
      window.localStorage.setItem(CHAVE, JSON.stringify(estado));
      return true;
    } catch (e) {
      console.warn('Falha ao salvar:', e);
      return false;
    }
  }

  function clonar(o) { return JSON.parse(JSON.stringify(o)); }

  var estado = carregar();
  if (estado.migrou) { delete estado.migrou; salvar(); }

  /* ---------- utilidades ---------- */
  function id() {
    return 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function normalizar(t) {
    return (t == null ? '' : String(t)).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  }

  function numero(v) {
    if (typeof v === 'number') return isFinite(v) ? v : 0;
    if (v == null) return 0;
    var s = String(v).replace(/[^\d,.-]/g, '');
    if (!s) return 0;
    if (s.indexOf(',') > -1) {
      // 1.250.000,50 -> o ponto é separador de milhar
      s = s.replace(/\./g, '').replace(',', '.');
    } else if (/^-?\d{1,3}(\.\d{3})+$/.test(s)) {
      // 1.250.000 (grupos exatos de 3) -> milhar, não decimal
      s = s.replace(/\./g, '');
    }
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }

  function moeda(v) {
    return (numero(v)).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 });
  }

  /** Valor formatado para reexibir no campo: 1250000 -> "1.250.000"; 1250000.5 -> "1.250.000,50". */
  function valorCampo(v) {
    var n = numero(v);
    if (!n) return '';
    var temCentavos = Math.round(n * 100) % 100 !== 0;
    return n.toLocaleString('pt-BR', {
      minimumFractionDigits: temCentavos ? 2 : 0,
      maximumFractionDigits: 2
    });
  }

  function moedaCurta(v) {
    var n = numero(v);
    if (Math.abs(n) >= 1e6) return 'R$ ' + (n / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mi';
    if (Math.abs(n) >= 1e3) return 'R$ ' + (n / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 0 }) + ' mil';
    return moeda(n);
  }

  /**
   * Interpreta "2026-08-17" no fuso local, ao meio-dia.
   * `new Date('2026-08-17')` seria meia-noite em UTC, que no Brasil (UTC-3)
   * cai no dia 16 — era por isso que toda data aparecia um dia atrasada.
   */
  function comoData(iso) {
    if (!iso) return null;
    var s = String(iso);
    var d = /^\d{4}-\d{2}-\d{2}$/.test(s) ? new Date(s + 'T12:00:00') : new Date(s);
    return isNaN(d) ? null : d;
  }

  function dataBR(iso) {
    var d = comoData(iso);
    if (!d) return '—';
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
  }

  function hojeISO() {
    var d = new Date();
    return d.getFullYear() + '-' + doisDig(d.getMonth() + 1) + '-' + doisDig(d.getDate());
  }

  function agoraHora() {
    var d = new Date();
    return doisDig(d.getHours()) + ':' + doisDig(d.getMinutes());
  }

  function doisDig(n) { return (n < 10 ? '0' : '') + n; }

  /** "14/03/26 · 09:30" — a hora só aparece quando existe. */
  function dataHoraBR(iso, hora) {
    var base = dataBR(iso);
    if (!hora) return base;
    return base + ' · ' + hora;
  }

  /** Chave para ordenar atividades por data e hora (registros antigos vão para o fim do dia). */
  function chaveMomento(a) {
    if (!a) return '';
    return (a.data || '') + 'T' + (a.hora || '23:59');
  }

  function diasDesde(iso) {
    var d = comoData(iso);
    if (!d) return null;
    return Math.floor((Date.now() - d.getTime()) / 86400000);
  }

  /** Deriva a data a partir do código do contrato (ddmmaa-nnn). */
  function dataDoContrato(contrato) {
    var m = /^(\d{2})(\d{2})(\d{2})-(\d{3})$/.exec(String(contrato || '').trim());
    if (!m) return '';
    var dia = +m[1], mes = +m[2], ano = 2000 + +m[3];
    if (mes < 1 || mes > 12 || dia < 1 || dia > 31) return '';
    return ano + '-' + String(mes).padStart(2, '0') + '-' + String(dia).padStart(2, '0');
  }

  var MESES_SIGLA = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];

  /** Sequencial do contrato (ddmmaa-nnn) — 497 em "140826-497". */
  function numeroProposta(contrato) {
    var m = /^(\d{2})(\d{2})(\d{2})-(\d{3})$/.exec(String(contrato || '').trim());
    return m ? +m[4] : null;
  }

  /**
   * Chave de ordenação pela numeração da proposta.
   * A sequência reinicia a cada ano, então o ano entra na frente para 2025 não
   * se misturar com 2026. Proposta sem numeração vai para o fim da fila.
   */
  function chaveSequencia(p) {
    var n = numeroProposta(p && p.contrato);
    var ano = (p && p.dataProposta ? String(p.dataProposta).slice(0, 4) : '') || '0000';
    return ano + '-' + (n == null ? '999999' : String(n).padStart(6, '0'));
  }

  /** Sequencial da proposta: os 3 últimos dígitos de ddmmaa-nnn. */
  function numeroProposta(contrato) {
    var m = /-(\d{1,4})\s*$/.exec(String(contrato || '').trim());
    return m ? +m[1] : null;
  }

  /** "JAN - SEM 03" -> {mes:1, semana:3} */
  function lerSemana(txt) {
    var meses = { JAN: 1, FEV: 2, MAR: 3, ABR: 4, MAI: 5, JUN: 6, JUL: 7, AGO: 8, SET: 9, OUT: 10, NOV: 11, DEZ: 12 };
    var m = /([A-ZÇ]{3})\s*-\s*SEM\s*(\d+)/i.exec(String(txt || '').toUpperCase());
    if (!m) return null;
    return { mes: meses[m[1]] || null, semana: +m[2] };
  }

  /**
   * Segunda-feira da "SEM n" de um mês.
   * Regra da planilha comercial: SEM 01 é a semana que começa na primeira
   * segunda do mês, SEM 02 na segunda segunda, e assim por diante (conferido
   * contra as datas dos contratos da base de 2026, 499/499).
   * Como o relatório fecha de segunda a domingo, devolver a segunda coloca o
   * registro na semana certa mesmo sem saber o dia exato.
   */
  function segundaDaSemana(mes, semana, ano) {
    if (!mes || !semana) return '';
    ano = ano || new Date().getFullYear();
    var primeiro = new Date(ano, mes - 1, 1);
    var ateSegunda = (8 - primeiro.getDay()) % 7;          // dias do dia 1 até a 1ª segunda
    var d = new Date(ano, mes - 1, 1 + ateSegunda + (semana - 1) * 7);
    /* "SEM 05" em mês com só 4 segundas: usa a última semana do próprio mês */
    while (d.getMonth() !== mes - 1) d.setDate(d.getDate() - 7);
    return emISO(d);
  }

  /** "MAI - SEM 04" -> "2026-05-25" (segunda-feira da semana). */
  function dataDaSemana(txt, anoRef) {
    var s = lerSemana(txt);
    if (!s || !s.mes) return '';
    return segundaDaSemana(s.mes, s.semana, anoRef || new Date().getFullYear());
  }

  /** "2026-05-27" -> "MAI - SEM 04" (o caminho inverso, mesma regra). */
  function rotuloSemana(iso) {
    if (!iso) return '';
    var d = new Date(iso + 'T12:00:00');
    if (isNaN(d)) return '';
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7));       // volta para a segunda
    return MESES_SIGLA[d.getMonth()] + ' - SEM ' + doisDig(Math.floor((d.getDate() - 1) / 7) + 1);
  }

  /* ---------- modelo ---------- */
  function novaProposta(dados) {
    var p = Object.assign({
      id: id(),
      contrato: '',
      cliente: '',
      cnpj: '',
      contato: '',
      telefone: '',
      email: '',
      cidade: '',
      estado: '',
      servico: '',
      descricao: '',
      obra: '',
      valor: 0,
      revisao: 0,
      arquivo: '',
      status: 'Nova',
      classificacao: 'Regular',
      temperatura: '',          /* vazio = ainda não classificada */
      tipoCliente: 'NOVO',
      vendedor: '',
      dataProposta: '',
      semanaConsulta: '',
      observacoes: '',
      proximoContato: '',
      motivoPerda: '',
      atividades: [],
      historicoStatus: [],
      criadoEm: new Date().toISOString(),
      atualizadoEm: new Date().toISOString()
    }, dados || {});
    if (!p.dataProposta) p.dataProposta = dataDoContrato(p.contrato) || hojeISO();
    if (!p.historicoStatus || !p.historicoStatus.length) {
      p.historicoStatus = [{ status: p.status, data: dataDoStatus(p) }];
    }
    return p;
  }

  /**
   * Data que deve constar no histórico para o status atual da proposta.
   * Fechada usa a semana de fechamento da planilha; o resto cai na emissão.
   * Nunca usa "hoje": a data de importação não é a data do evento.
   */
  function dataDoStatus(p) {
    if (!p) return hojeISO();
    if (p.status === 'Fechada' && p.dataFechamento) return p.dataFechamento;
    if (p.status === 'Perdida' && p.dataPerda) return p.dataPerda;
    return p.dataProposta || hojeISO();
  }

  /** Devolve a atividade mais recente (data + hora), ou null. */
  function ultimaAtividade(p) {
    var lista = (p.atividades || []).filter(function (a) { return a && a.data; });
    if (!lista.length) return null;
    return lista.slice().sort(function (a, b) {
      return chaveMomento(a).localeCompare(chaveMomento(b));
    })[lista.length - 1];
  }

  function ultimoContato(p) {
    var a = ultimaAtividade(p);
    return a ? a.data : null;
  }

  function diasSemContato(p) {
    var ref = ultimoContato(p) || p.dataProposta;
    return diasDesde(ref);
  }

  /** Data em que a proposta virou Fechada (histórico de etapas > campo da planilha > emissão). */
  function dataDeFechamento(p) {
    if (!p || p.status !== 'Fechada') return '';
    var hist = (p.historicoStatus || []).filter(function (h) { return h.status === 'Fechada' && h.data; });
    if (hist.length) return hist[hist.length - 1].data;
    return p.dataFechamento || p.dataProposta || '';
  }

  /** Dias entre a emissão da proposta e o fechamento. */
  function diasParaFechar(p) {
    var f = dataDeFechamento(p);
    if (!f || !p.dataProposta) return '';
    var d = Math.round((new Date(f + 'T12:00:00') - new Date(p.dataProposta + 'T12:00:00')) / 86400000);
    return isFinite(d) && d >= 0 ? d : '';
  }

  function entradaNaEtapa(p) {
    var hist = (p.historicoStatus || []).filter(function (h) { return h.status === p.status; });
    if (hist.length) return hist[hist.length - 1].data;
    return p.dataProposta || null;
  }

  function diasNaEtapa(p) {
    return diasDesde(entradaNaEtapa(p));
  }

  function urgencia(p) {
    if (!STATUS_ABERTOS.includes(p.status)) return 'ok';
    var d = diasSemContato(p);
    var limite = estado.config.diasFollowup || 15;
    if (d == null) return 'medio';
    if (d >= limite * 2) return 'alto';
    if (d >= limite) return 'medio';
    return 'ok';
  }

  /** Dias até o próximo contato agendado: 0 = hoje, negativo = atrasado, null = sem agenda. */
  function diasParaProximo(p) {
    if (!p.proximoContato) return null;
    var d = diasDesde(p.proximoContato);
    return d == null ? null : -d;
  }

  function agendaStatus(p) {
    var d = diasParaProximo(p);
    if (d == null) return 'sem';
    if (d < 0) return 'atrasado';
    if (d === 0) return 'hoje';
    if (d <= 7) return 'semana';
    return 'futuro';
  }

  function contarAtividades(p, tipo) {
    return (p.atividades || []).filter(function (a) { return a.tipo === tipo; }).length;
  }

  /* ---------- operações ---------- */
  function adicionar(p) {
    estado.propostas.push(novaProposta(p));
    salvar();
  }

  /** Registra a mudança de etapa. `data` só fica em branco em mudança feita na tela. */
  function anotarEtapa(p, novoStatus, data) {
    if (!novoStatus || novoStatus === p.status) return;
    p.historicoStatus = p.historicoStatus || [];
    p.historicoStatus.push({ status: novoStatus, data: data || hojeISO() });
    p.historicoStatus.sort(function (a, b) {
      return String(a.data || '').localeCompare(String(b.data || ''));
    });
  }

  function atualizar(idProposta, campos) {
    var p = estado.propostas.find(function (x) { return x.id === idProposta; });
    if (!p) return null;
    if (campos && campos.status) anotarEtapa(p, campos.status);
    Object.assign(p, campos, { atualizadoEm: new Date().toISOString() });
    if (p.status !== 'Perdida') p.motivoPerda = '';
    /* proposta encerrada não fica pendurada na agenda */
    if (p.status === 'Fechada' || p.status === 'Perdida') p.proximoContato = '';
    salvar();
    return p;
  }

  function remover(idProposta) {
    estado.propostas = estado.propostas.filter(function (x) { return x.id !== idProposta; });
    salvar();
  }

  /** Remove várias de uma vez, gravando uma única vez. */
  function removerVarios(ids) {
    var alvo = (ids || []).slice();
    if (!alvo.length) return 0;
    var antes = estado.propostas.length;
    estado.propostas = estado.propostas.filter(function (x) { return alvo.indexOf(x.id) === -1; });
    salvar();
    return antes - estado.propostas.length;
  }

  function registrarAtividade(idProposta, atividade) {
    var p = estado.propostas.find(function (x) { return x.id === idProposta; });
    if (!p) return null;
    p.atividades = p.atividades || [];
    p.atividades.push(Object.assign({
      id: id(), tipo: 'Ligação', data: hojeISO(), hora: agoraHora(),
      responsavel: p.vendedor || '', obs: ''
    }, atividade || {}));
    var lancada = p.atividades[p.atividades.length - 1];
    /* o follow-up agendado foi cumprido: sai da agenda, salvo se um novo for marcado na hora */
    if (p.proximoContato && p.proximoContato <= (lancada.data || hojeISO())) p.proximoContato = '';
    p.atualizadoEm = new Date().toISOString();
    salvar();
    return p;
  }

  function removerAtividade(idProposta, idAtividade) {
    var p = estado.propostas.find(function (x) { return x.id === idProposta; });
    if (!p) return;
    p.atividades = (p.atividades || []).filter(function (a) { return a.id !== idAtividade; });
    salvar();
  }

  /**
   * Junta propostas importadas com as existentes.
   * A chave é contrato + cliente: mesmo contrato com cliente diferente é erro
   * de numeração na planilha, não a mesma obra. Antes o segundo registro
   * sobrescrevia o primeiro em silêncio e a proposta original sumia da base.
   */
  function mesclar(lista, opcoes) {
    opcoes = opcoes || {};
    var novos = 0, atualizados = 0, conflitos = [];
    lista.forEach(function (item) {
      var chave = String(item.contrato || '').trim();
      var mesmoContrato = chave ? estado.propostas.filter(function (p) {
        return String(p.contrato || '').trim() === chave;
      }) : [];
      var alvo = normalizar(item.cliente);
      var existente = mesmoContrato.find(function (p) {
        return normalizar(p.cliente) === alvo;
      }) || (alvo ? null : mesmoContrato[0]);

      if (!existente && mesmoContrato.length) {
        conflitos.push({
          contrato: chave,
          clientes: mesmoContrato.map(function (p) { return p.cliente; }).concat(item.cliente)
        });
      }

      if (existente) {
        if (item.status && !(opcoes.preservarEdicoes)) {
          anotarEtapa(existente, item.status, dataDoStatus(item));
        }
        Object.keys(item).forEach(function (k) {
          if (k === 'id' || k === 'atividades' || k === 'criadoEm') return;
          var v = item[k];
          var vazio = v === '' || v == null || (k === 'valor' && !v);
          if (vazio) return;
          if (opcoes.preservarEdicoes &&
              ['status', 'classificacao', 'temperatura', 'vendedor', 'observacoes', 'proximoContato', 'motivoPerda'].includes(k)) return;
          existente[k] = v;
        });
        existente.atualizadoEm = new Date().toISOString();
        atualizados++;
      } else {
        estado.propostas.push(novaProposta(item));
        novos++;
      }
    });
    salvar();
    return { novos: novos, atualizados: atualizados, conflitos: conflitos };
  }

  function substituirTudo(dados) {
    estado = Object.assign(clonar(padrao), dados || {});
    estado.propostas = (estado.propostas || []).map(function (p) { return novaProposta(p); });
    salvar();
  }

  function limpar() {
    estado = clonar(padrao);
    estado.propostas = [];
    salvar();
  }

  /* ---------- agregações ---------- */
  function filtrar(filtros) {
    filtros = filtros || {};
    var termo = normalizar(filtros.busca || '');
    var corte = null, teto = null;
    var periodo = String(filtros.periodo || 'tudo');
    var anoEscolhido = /^ano:(\d{4})$/.exec(periodo);
    if (/^\d+$/.test(periodo)) {
      corte = somaISO(hojeISO(), -parseInt(periodo, 10));
    } else if (anoEscolhido) {
      corte = anoEscolhido[1] + '-01-01';
      teto = anoEscolhido[1] + '-12-31';
    } else if (periodo === 'ano') {           // compatibilidade com backups antigos
      corte = new Date().getFullYear() + '-01-01';
    }

    return estado.propostas.filter(function (p) {
      if (filtros.status && p.status !== filtros.status) return false;
      if (filtros.classificacao && p.classificacao !== filtros.classificacao) return false;
      /* 'sem' junta as que ainda não foram classificadas — é a fila de triagem */
      if (filtros.temperatura === 'sem' && p.temperatura) return false;
      if (filtros.temperatura && filtros.temperatura !== 'sem' && p.temperatura !== filtros.temperatura) return false;
      if (filtros.estado && p.estado !== filtros.estado) return false;
      if (filtros.vendedor && p.vendedor !== filtros.vendedor) return false;
      if (filtros.somenteAbertas && !STATUS_ABERTOS.includes(p.status)) return false;
      if (anoEscolhido) {
        if (anoDaProposta(p) !== anoEscolhido[1]) return false;
      } else {
        if (corte && (p.dataProposta || '') < corte) return false;
        if (teto && (p.dataProposta || '') > teto) return false;
      }
      if (termo) {
        var alvo = normalizar([p.cliente, p.contrato, p.contato, p.cidade, p.estado, p.servico, p.obra, p.email].join(' '));
        if (alvo.indexOf(termo) === -1) return false;
      }
      return true;
    });
  }

  function resumo(lista) {
    var total = lista.length;
    var abertas = lista.filter(function (p) { return STATUS_ABERTOS.includes(p.status); });
    var fechadas = lista.filter(function (p) { return p.status === 'Fechada'; });
    var perdidas = lista.filter(function (p) { return p.status === 'Perdida'; });
    var soma = function (arr) { return arr.reduce(function (s, p) { return s + numero(p.valor); }, 0); };
    var decididas = fechadas.length + perdidas.length;
    return {
      total: total,
      abertas: abertas.length,
      fechadas: fechadas.length,
      perdidas: perdidas.length,
      valorTotal: soma(lista),
      valorAberto: soma(abertas),
      valorFechado: soma(fechadas),
      ticketMedio: fechadas.length ? soma(fechadas) / fechadas.length : 0,
      conversao: total ? (fechadas.length / total) * 100 : 0,
      taxaGanho: decididas ? (fechadas.length / decididas) * 100 : 0,
      decididas: decididas,
      atrasadas: abertas.filter(function (p) { return urgencia(p) !== 'ok'; }).length,
      boas: lista.filter(function (p) { return p.classificacao === 'Boa'; }).length,
      regulares: lista.filter(function (p) { return p.classificacao === 'Regular'; }).length,
      ruins: lista.filter(function (p) { return p.classificacao === 'Ruim'; }).length,
      quentes: lista.filter(function (p) { return p.temperatura === 'Quente'; }).length,
      mornas: lista.filter(function (p) { return p.temperatura === 'Morno'; }).length,
      frias: lista.filter(function (p) { return p.temperatura === 'Frio'; }).length,
      semTemperatura: lista.filter(function (p) { return !p.temperatura; }).length
    };
  }

  /** Anos com propostas na base, do mais recente para o mais antigo. */
  function anosComPropostas() {
    var anos = {};
    estado.propostas.forEach(function (p) {
      var a = anoDaProposta(p);
      if (a) anos[a] = (anos[a] || 0) + 1;
    });
    return Object.keys(anos).sort().reverse().map(function (a) { return { ano: a, qtd: anos[a] }; });
  }

  /** Ano da proposta: data preenchida, senão o número do contrato, senão quando entrou no app. */
  function anoDaProposta(p) {
    var candidatos = [p.dataProposta, dataDoContrato(p.contrato), p.dataFechamento, p.criadoEm];
    for (var i = 0; i < candidatos.length; i++) {
      var a = String(candidatos[i] || '').slice(0, 4);
      if (/^(19|20)\d{2}$/.test(a)) return a;
    }
    return '';
  }

  function agruparPor(lista, chave) {
    var mapa = {};
    lista.forEach(function (p) {
      var k = (typeof chave === 'function' ? chave(p) : p[chave]) || '—';
      if (!mapa[k]) mapa[k] = { chave: k, qtd: 0, valor: 0, itens: [] };
      mapa[k].qtd++;
      mapa[k].valor += numero(p.valor);
      mapa[k].itens.push(p);
    });
    return Object.keys(mapa).map(function (k) { return mapa[k]; })
      .sort(function (a, b) { return b.valor - a.valor || b.qtd - a.qtd; });
  }

  function porMes(lista) {
    var meses = [];
    for (var i = 1; i <= 12; i++) meses.push({ mes: i, enviadas: 0, fechadas: 0, valorFechado: 0 });
    lista.forEach(function (p) {
      var d = comoData(p.dataProposta);
      if (d) meses[d.getMonth()].enviadas++;
      if (p.status === 'Fechada') {
        var f = comoData(dataDeFechamento(p));
        if (f) { meses[f.getMonth()].fechadas++; meses[f.getMonth()].valorFechado += numero(p.valor); }
      }
    });
    return meses;
  }

  /** Divide "PIT PDA PCE HELICOIDAL" em serviços individuais.
   *  Compara sem acento e testa os nomes longos primeiro, para "PCE HELICOIDAL"
   *  não ser contado como "PCE" nem "PROJETO DE FUNDAÇÕES" como "PROJETO". */
  function servicos(p) {
    var bruto = String(p.servico || '').trim();
    if (!bruto) return [];
    var resto = ' ' + normalizar(bruto) + ' ';
    var conhecidos = SERVICOS.concat(SERVICOS_LEGADO).sort(function (a, b) { return b.length - a.length; });
    var achados = [];
    conhecidos.forEach(function (nome) {
      var alvo = normalizar(nome);
      if (resto.indexOf(alvo) > -1) {
        achados.push(nome);
        resto = resto.split(alvo).join(' ');
      }
    });
    if (!achados.length) return [bruto.toUpperCase()];
    /* devolve na ordem em que a lista oficial define, para os gráficos ficarem estáveis */
    var ordem = SERVICOS.concat(SERVICOS_LEGADO);
    return achados.sort(function (a, b) { return ordem.indexOf(a) - ordem.indexOf(b); });
  }

  /* ---------- relatório semanal ---------- */

  /** Segunda a domingo da semana que contém a data informada. */
  function semanaDe(iso) {
    var d = iso ? new Date(iso + 'T12:00:00') : new Date();
    if (isNaN(d)) d = new Date();
    var dia = d.getDay();                    // 0 = domingo
    var desloca = dia === 0 ? -6 : 1 - dia;  // volta para a segunda
    var ini = new Date(d.getTime());
    ini.setDate(ini.getDate() + desloca);
    var fim = new Date(ini.getTime());
    fim.setDate(fim.getDate() + 6);
    return { inicio: emISO(ini), fim: emISO(fim) };
  }

  function emISO(d) {
    return d.getFullYear() + '-' + doisDig(d.getMonth() + 1) + '-' + doisDig(d.getDate());
  }

  function somaISO(iso, dias) {
    var d = new Date(iso + 'T12:00:00');
    d.setDate(d.getDate() + dias);
    return emISO(d);
  }

  /** Última mudança para um status dentro da janela (usa o histórico de etapas). */
  function mudouPara(p, status, inicio, fim) {
    var achou = (p.historicoStatus || []).filter(function (h) {
      return h.status === status && h.data >= inicio && h.data <= fim;
    });
    return achou.length ? achou[achou.length - 1].data : null;
  }

  /**
   * Números da semana para a reunião: o que fechou, o que se perdeu,
   * o que entrou, o esforço de cada vendedor e a agenda da semana seguinte.
   */
  function relatorioSemana(inicio, lista) {
    var base = lista || estado.propostas;
    var semana = semanaDe(inicio);
    var ini = semana.inicio, fim = semana.fim;
    var proxIni = somaISO(fim, 1), proxFim = somaISO(fim, 7);

    var fechadas = [], perdidas = [], novas = [];
    base.forEach(function (p) {
      var f = p.status === 'Fechada' ? mudouPara(p, 'Fechada', ini, fim) : null;
      if (f) fechadas.push({ p: p, data: f });
      var x = p.status === 'Perdida' ? mudouPara(p, 'Perdida', ini, fim) : null;
      if (x) perdidas.push({ p: p, data: x });
      if ((p.dataProposta || '') >= ini && (p.dataProposta || '') <= fim) novas.push(p);
    });

    var abertas = base.filter(function (p) { return STATUS_ABERTOS.includes(p.status); });
    var hoje = hojeISO();
    /* agenda = daqui até o fim da próxima semana, para não sumir o que foi marcado
       para os dias restantes da semana em análise */
    var agenda = abertas.filter(function (p) {
      return p.proximoContato && p.proximoContato >= hoje && p.proximoContato <= proxFim;
    }).sort(function (a, b) { return a.proximoContato.localeCompare(b.proximoContato); });
    var atrasados = abertas.filter(function (p) {
      return p.proximoContato && p.proximoContato < hoje;
    }).sort(function (a, b) { return a.proximoContato.localeCompare(b.proximoContato); });
    var semAgenda = abertas.filter(function (p) { return !p.proximoContato && urgencia(p) !== 'ok'; });

    /* contatos da semana por vendedor */
    var porVendedor = {};
    function linha(nome) {
      if (!porVendedor[nome]) {
        porVendedor[nome] = { vendedor: nome, contatos: 0, ligacoes: 0, reunioes: 0, fechado: 0, agendados: 0 };
      }
      return porVendedor[nome];
    }
    (estado.vendedores || []).forEach(linha);
    base.forEach(function (p) {
      (p.atividades || []).forEach(function (a) {
        if (!a.data || a.data < ini || a.data > fim) return;
        var l = linha(a.responsavel || p.vendedor || 'Sem vendedor');
        l.contatos++;
        if (a.tipo === 'Ligação') l.ligacoes++;
        if (a.tipo === 'Reunião') l.reunioes++;
      });
    });
    fechadas.forEach(function (f) { linha(f.p.vendedor || 'Sem vendedor').fechado += numero(f.p.valor); });
    agenda.forEach(function (p) { linha(p.vendedor || 'Sem vendedor').agendados++; });

    /* motivos das perdas da semana */
    var motivos = {};
    perdidas.forEach(function (x) {
      var m = x.p.motivoPerda || 'Não informado';
      motivos[m] = (motivos[m] || 0) + 1;
    });

    return {
      inicio: ini, fim: fim, proximaInicio: proxIni, proximaFim: proxFim,
      fechadas: fechadas, perdidas: perdidas, novas: novas,
      valorFechado: fechadas.reduce(function (t, f) { return t + numero(f.p.valor); }, 0),
      valorPerdido: perdidas.reduce(function (t, x) { return t + numero(x.p.valor); }, 0),
      valorNovo: novas.reduce(function (t, p) { return t + numero(p.valor); }, 0),
      motivos: motivos,
      agenda: agenda, atrasados: atrasados, semAgenda: semAgenda,
      equipe: Object.keys(porVendedor).map(function (k) { return porVendedor[k]; })
        .sort(function (a, b) { return b.contatos - a.contatos; }),
      abertasValor: abertas.reduce(function (t, p) { return t + numero(p.valor); }, 0),
      abertasQtd: abertas.length
    };
  }

  /* ---------- exportação ---------- */
  window.Store = {
    STATUS: STATUS,
    STATUS_ABERTOS: STATUS_ABERTOS,
    CLASSIFICACOES: CLASSIFICACOES,
    TEMPERATURAS: TEMPERATURAS,
    TIPOS_CLIENTE: TIPOS_CLIENTE,
    TIPOS_ATIVIDADE: TIPOS_ATIVIDADE,
    SERVICOS: SERVICOS,
    get estado() { return estado; },
    get propostas() { return estado.propostas; },
    get config() { return estado.config; },
    get vendedores() { return estado.vendedores; },
    salvar: salvar,
    localOk: localOk,
    id: id,
    normalizar: normalizar,
    numero: numero,
    moeda: moeda,
    moedaCurta: moedaCurta,
    valorCampo: valorCampo,
    MOTIVOS_PERDA: MOTIVOS_PERDA,
    dataBR: dataBR,
    dataHoraBR: dataHoraBR,
    chaveMomento: chaveMomento,
    hojeISO: hojeISO,
    agoraHora: agoraHora,
    diasDesde: diasDesde,
    dataDoContrato: dataDoContrato,
    numeroProposta: numeroProposta,
    lerSemana: lerSemana,
    dataDaSemana: dataDaSemana,
    segundaDaSemana: segundaDaSemana,
    rotuloSemana: rotuloSemana,
    dataDoStatus: dataDoStatus,
    novaProposta: novaProposta,
    ultimoContato: ultimoContato,
    ultimaAtividade: ultimaAtividade,
    diasSemContato: diasSemContato,
    urgencia: urgencia,
    entradaNaEtapa: entradaNaEtapa,
    diasNaEtapa: diasNaEtapa,
    dataDeFechamento: dataDeFechamento,
    diasParaFechar: diasParaFechar,
    somaISO: somaISO,
    diasParaProximo: diasParaProximo,
    agendaStatus: agendaStatus,
    semanaDe: semanaDe,
    relatorioSemana: relatorioSemana,
    contarAtividades: contarAtividades,
    adicionar: adicionar,
    atualizar: atualizar,
    remover: remover,
    removerVarios: removerVarios,
    registrarAtividade: registrarAtividade,
    removerAtividade: removerAtividade,
    mesclar: mesclar,
    substituirTudo: substituirTudo,
    limpar: limpar,
    filtrar: filtrar,
    resumo: resumo,
    agruparPor: agruparPor,
    anosComPropostas: anosComPropostas,
    anoDaProposta: anoDaProposta,
    porMes: porMes,
    servicos: servicos
  };
})();
