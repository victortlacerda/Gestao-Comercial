/* ===========================================================
   app.js — telas, interações e renderização
   =========================================================== */
(function () {
  'use strict';

  var S = window.Store;
  var I = window.Importers;

  var el = function (id) { return document.getElementById(id); };
  var esc = function (t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  var TITULOS = {
    painel: ['Painel', 'Visão geral do comercial'],
    funil: ['Funil', 'Arraste as propostas entre as etapas'],
    propostas: ['Propostas', 'Base completa, com filtros e busca'],
    followup: ['Follow-up', 'Quem precisa de contato agora'],
    equipe: ['Equipe', 'Ligações, reuniões e resultados por vendedor'],
    relatorio: ['Relatório', 'Uma página para a reunião de segunda'],
    dados: ['Importar', 'Planilha, PDFs e backups'],
    config: ['Ajustes', 'Metas e equipe comercial']
  };

  var LIMITE_TABELA = 400;   // teto de linhas desenhadas de uma vez

  var estadoUI = {
    view: 'painel',
    periodo: 'tudo',
    ordem: { campo: 'numero', desc: true },
    propostaAberta: null,
    rascunho: null,          /* proposta em preenchimento, ainda não salva */
    rascunhoTocado: false,
    selecao: [],
    fuLimite: 120,
    relSemana: ''
  };

  /* ---------------- helpers de UI ---------------- */

  function toast(msg) {
    var t = el('toast');
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.hidden = true; }, 2600);
  }

  function logar(caixaId, msg) {
    var box = el(caixaId);
    var linha = document.createElement('div');
    linha.textContent = msg;
    box.appendChild(linha);
    box.scrollTop = box.scrollHeight;
  }

  function tagClassificacao(c) {
    var mapa = { Boa: 'tag-ok', Regular: 'tag-warn', Ruim: 'tag-bad' };
    return '<span class="tag ' + (mapa[c] || 'tag-neutral') + '">' + esc(c || '—') + '</span>';
  }

  /** Temperatura. Sem valor não desenha nada — não polui a lista com "—". */
  function tagTemperatura(t) {
    if (!t) return '';
    var mapa = { Quente: 'tag-quente', Morno: 'tag-morno', Frio: 'tag-frio' };
    var icone = { Quente: '🔥', Morno: '🌤', Frio: '❄' };
    return '<span class="tag ' + (mapa[t] || 'tag-neutral') + '">' + (icone[t] || '') + ' ' + esc(t) + '</span>';
  }

  function tagStatus(s) {
    var mapa = { Fechada: 'tag-ok', Perdida: 'tag-bad', 'Em negociação': 'tag-neutral', 'Aguardando retorno': 'tag-warn' };
    return '<span class="tag ' + (mapa[s] || 'tag-neutral') + '">' + esc(s) + '</span>';
  }

  function seloRevisao(p) {
    return p.revisao ? ' <span class="tag tag-neutral">Rev.' + String(p.revisao).padStart(2, '0') + '</span>' : '';
  }

  function textoEtapa(p) {
    var d = S.diasNaEtapa(p);
    if (d == null) return '';
    if (d === 0) return 'entrou hoje';
    return d + ' dia' + (d > 1 ? 's' : '') + ' nesta etapa';
  }

  /** comHora: só o drawer mostra o horário; nas listas o rótulo ficaria comprido demais. */
  function textoContato(p, comHora) {
    var d = S.diasSemContato(p);
    var a = S.ultimaAtividade(p);
    if (d == null) return 'sem registro';
    if (!a) return 'nenhum contato há ' + d + 'd';
    return (comHora ? S.dataHoraBR(a.data, a.hora) : S.dataBR(a.data)) + ' · ' + d + 'd';
  }

  /** Aceita strings ou {v, rotulo} — o segundo formato serve para dar nome ao
      valor vazio ("— não definida") em vez de deixar uma linha em branco. */
  function opcoes(lista, selecionado) {
    return lista.map(function (item) {
      var v = (item && typeof item === 'object') ? item.v : item;
      var rotulo = (item && typeof item === 'object') ? item.rotulo : item;
      return '<option value="' + esc(v) + '"' + (v === selecionado ? ' selected' : '') + '>' + esc(rotulo) + '</option>';
    }).join('');
  }

  /** Lista de temperaturas com o vazio nomeado, para os dois formulários. */
  function listaTemperaturas() {
    return [{ v: '', rotulo: '— não definida' }].concat(S.TEMPERATURAS);
  }

  function filtrosAtuais(extra) {
    return Object.assign({ periodo: estadoUI.periodo }, extra || {});
  }

  /* ---------------- navegação ---------------- */

  function mostrarView(nome) {
    if (estadoUI.rascunho) {
      if (!podeDescartarRascunho()) return;
      fecharDrawer(true);
    }
    estadoUI.view = nome;
    document.querySelectorAll('.view').forEach(function (v) { v.classList.remove('is-active'); });
    var alvo = el('view-' + nome);
    if (alvo) alvo.classList.add('is-active');
    document.querySelectorAll('.nav-item, .tab').forEach(function (b) {
      b.classList.toggle('is-active', b.dataset.view === nome);
    });
    preencherPeriodos();   /* a lista de anos muda conforme a base é importada */
    el('aviso-base-vazia').hidden = S.propostas.length > 0 || nome === 'dados';
    el('view-title').textContent = TITULOS[nome][0];
    el('view-subtitle').textContent = TITULOS[nome][1];
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
    renderizarView(nome);
  }

  function renderizarView(nome) {
    if (nome === 'painel') renderPainel();
    if (nome === 'funil') renderFunil();
    if (nome === 'propostas') renderPropostas();
    if (nome === 'followup') renderFollowup();
    if (nome === 'equipe') renderEquipe();
    if (nome === 'relatorio') renderRelatorio();
    if (nome === 'config') renderConfig();
  }

  function renderTudo() {
    preencherSelects();
    renderizarView(estadoUI.view);
  }

  /* ---------------- painel ---------------- */

  function renderPainel() {
    var lista = S.filtrar(filtrosAtuais());
    var r = S.resumo(lista);
    var cfg = S.config;

    var mesAtual = S.hojeISO().slice(0, 7);
    var doMes = lista.filter(function (p) {
      return (p.dataProposta || '').slice(0, 7) === mesAtual;
    });
    var fechadoMes = lista.filter(function (p) {
      return p.status === 'Fechada' && S.dataDeFechamento(p).slice(0, 7) === mesAtual;
    }).reduce(function (s, p) { return s + S.numero(p.valor); }, 0);

    var pctPropostas = cfg.metaPropostas ? Math.min(100, doMes.length / cfg.metaPropostas * 100) : 0;
    var pctValor = cfg.metaValor ? Math.min(100, fechadoMes / cfg.metaValor * 100) : 0;

    el('kpis').innerHTML = [
      kpi('Propostas no período', r.total, r.abertas + ' em aberto · ' + r.fechadas + ' fechadas'),
      kpi('Valor em aberto', S.moedaCurta(r.valorAberto), r.abertas + ' propostas aguardando decisão'),
      kpi('Valor fechado', S.moedaCurta(r.valorFechado), 'Ticket médio ' + S.moedaCurta(r.ticketMedio)),
      kpi('Conversão', r.conversao.toFixed(0) + '%', r.fechadas + ' fechadas de ' + r.total + ' · ' + r.taxaGanho.toFixed(0) + '% entre as decididas'),
      kpi('Sem contato há tempo', r.atrasadas, 'limite de ' + cfg.diasFollowup + ' dias', r.atrasadas > 0),
      kpi('Meta do mês', doMes.length + '/' + cfg.metaPropostas, S.moedaCurta(fechadoMes) + ' de ' + S.moedaCurta(cfg.metaValor), false, Math.max(pctPropostas, pctValor))
    ].join('');

    // funil
    var etapas = [
      { nome: 'Novas', status: ['Nova'] },
      { nome: 'Enviadas', status: ['Enviada'] },
      { nome: 'Em negociação', status: ['Em negociação'] },
      { nome: 'Aguardando retorno', status: ['Aguardando retorno'] },
      { nome: 'Fechadas', status: ['Fechada'], tom: 'ok' },
      { nome: 'Perdidas', status: ['Perdida'], tom: 'bad' }
    ];
    var maior = 1;
    etapas.forEach(function (e) {
      e.itens = lista.filter(function (p) { return e.status.includes(p.status); });
      e.valor = e.itens.reduce(function (s, p) { return s + S.numero(p.valor); }, 0);
      if (e.itens.length > maior) maior = e.itens.length;
    });
    el('funnel-bars').innerHTML = etapas.map(function (e) {
      var largura = Math.max(3, e.itens.length / maior * 100);
      var dias = e.itens.map(function (p) { return S.diasNaEtapa(p); }).filter(function (d) { return d != null; });
      var media = dias.length ? Math.round(dias.reduce(function (a, b) { return a + b; }, 0) / dias.length) : null;
      var nota = media == null ? '' : ' <span style="color:var(--ink-soft);font-weight:500">· ' + media + 'd na etapa</span>';
      return '<div class="funnel-row" data-tone="' + (e.tom || '') + '">' +
        '<span class="funnel-name">' + e.nome + '</span>' +
        '<div class="funnel-track"><div class="funnel-fill" style="width:' + largura + '%">' + e.itens.length + '</div></div>' +
        '<span class="funnel-value">' + S.moedaCurta(e.valor) + nota + '</span></div>';
    }).join('');
    el('funnel-note').textContent = r.conversao.toFixed(0) + '% das propostas viraram contrato';

    // listas
    var abertas = lista.filter(function (p) { return S.STATUS_ABERTOS.includes(p.status); })
      .sort(function (a, b) { return S.numero(b.valor) - S.numero(a.valor); }).slice(0, 6);
    el('top-oportunidades').innerHTML = abertas.length ? abertas.map(function (p) {
      return '<div class="mini-row clickable" data-abrir="' + p.id + '"><div class="m-main"><strong>' + esc(p.cliente) + '</strong>' +
        '<small>' + esc(p.contrato || '—') + ' · ' + esc(p.cidade || '—') + ' · ' + textoContato(p) + '</small></div>' +
        '<span class="m-val">' + S.moedaCurta(p.valor) + '</span></div>';
    }).join('') : vazio('Nenhuma proposta aberta no período.');

    var clientes = S.agruparPor(lista.filter(function (p) { return p.status === 'Fechada'; }), 'cliente').slice(0, 6);
    el('top-clientes').innerHTML = clientes.length ? clientes.map(function (g) {
      return '<div class="mini-row"><div class="m-main"><strong>' + esc(g.chave) + '</strong><small>' + g.qtd + ' proposta(s) fechada(s)</small></div>' +
        '<span class="m-val">' + S.moedaCurta(g.valor) + '</span></div>';
    }).join('') : vazio('Nenhuma proposta fechada ainda.');

    if (window.Charts && window.Chart) {
      Charts.base();
      Charts.porMes(lista);
      Charts.classificacao(r);
      var modoEstado = el('ch-estado-modo').value;
      el('ch-estado-titulo').textContent =
        (modoEstado === 'fechado' ? 'Valor fechado por estado' : 'Valor cotado por estado') + ' (top 8)';
      Charts.porEstado(lista, modoEstado);
      Charts.porServico(lista);
    }
  }

  function kpi(rotulo, valor, rodape, alerta, medidor) {
    return '<div class="kpi"><div class="kpi-label">' + esc(rotulo) + '</div>' +
      '<div class="kpi-value">' + esc(valor) + '</div>' +
      '<div class="kpi-foot' + (alerta ? ' is-bad' : '') + '">' + esc(rodape) + '</div>' +
      (medidor != null ? '<div class="kpi-meter"><i style="width:' + Math.round(medidor) + '%"></i></div>' : '') +
      '</div>';
  }

  function vazio(msg) { return '<p class="empty">' + esc(msg) + '</p>'; }

  /* ---------------- funil (kanban) ---------------- */

  function renderFunil() {
    var lista = S.filtrar(filtrosAtuais({
      busca: el('busca-funil').value,
      vendedor: el('funil-vendedor').value
    }));
    el('kanban').innerHTML = S.STATUS.map(function (status) {
      var itens = lista.filter(function (p) { return p.status === status; })
        .sort(function (a, b) { return S.numero(b.valor) - S.numero(a.valor); });
      var soma = itens.reduce(function (s, p) { return s + S.numero(p.valor); }, 0);
      return '<div class="column" data-status="' + esc(status) + '">' +
        '<div class="column-head"><strong>' + esc(status) + '</strong><span class="column-count">' + itens.length + '</span></div>' +
        '<div class="column-sum">' + S.moedaCurta(soma) + '</div>' +
        '<div class="column-body">' + (itens.length ? itens.map(cardHTML).join('') : '<p class="empty">Vazio</p>') + '</div></div>';
    }).join('');
    ligarArrastar();
  }

  function cardHTML(p) {
    var urg = S.urgencia(p);
    var cor = urg === 'alto' ? 'tag-bad' : urg === 'medio' ? 'tag-warn' : 'tag-ok';
    return '<article class="card" draggable="true" data-id="' + p.id + '">' +
      '<div class="card-top"><span>' + esc(p.contrato || '—') + seloRevisao(p) + '</span>' +
      '<span class="tag-pair">' + tagClassificacao(p.classificacao) + tagTemperatura(p.temperatura) + '</span></div>' +
      '<h3 class="card-title">' + esc(p.cliente || 'Sem cliente') + '</h3>' +
      '<div class="card-top"><span>' + esc([p.cidade, p.estado].filter(Boolean).join('/') || '—') + '</span></div>' +
      '<div class="card-meta"><span class="tag ' + cor + '">' + esc(textoContato(p)) + '</span>' +
      '<span class="card-value">' + S.moedaCurta(p.valor) + '</span></div>' +
      '<span class="stage-age">' + esc(textoEtapa(p)) + '</span></article>';
  }

  function ligarArrastar() {
    var arrastando = null;
    document.querySelectorAll('#kanban .card').forEach(function (card) {
      card.addEventListener('dragstart', function () { arrastando = card; card.classList.add('dragging'); });
      card.addEventListener('dragend', function () { card.classList.remove('dragging'); arrastando = null; });
      card.addEventListener('click', function () { abrirProposta(card.dataset.id); });
    });
    document.querySelectorAll('#kanban .column').forEach(function (col) {
      col.addEventListener('dragover', function (e) { e.preventDefault(); col.classList.add('drag-over'); });
      col.addEventListener('dragleave', function () { col.classList.remove('drag-over'); });
      col.addEventListener('drop', function (e) {
        e.preventDefault();
        col.classList.remove('drag-over');
        if (!arrastando) return;
        var alvo = arrastando.dataset.id;
        S.atualizar(alvo, { status: col.dataset.status });
        toast('Status alterado para ' + col.dataset.status);
        renderFunil();
        /* perdeu: abre a proposta já pedindo o motivo */
        if (col.dataset.status === 'Perdida') abrirProposta(alvo);
      });
    });
  }

  /* ---------------- propostas ---------------- */

  /* Ordenação da lista de propostas.
     `desc` guarda o sentido padrão de cada campo: número, valor e tempo abrem
     do maior para o menor; texto abre em A–Z. */
  var ORDENS = {
    numero:         { rotulo: 'Nº da proposta', desc: true },
    cliente:        { rotulo: 'Cliente', desc: false },
    cidade:         { rotulo: 'Cidade/UF', desc: false },
    servico:        { rotulo: 'Serviço', desc: false },
    valor:          { rotulo: 'Valor', desc: true },
    classificacao:  { rotulo: 'Classificação', desc: false },
    temperatura:    { rotulo: 'Temperatura', desc: false },
    status:         { rotulo: 'Status', desc: false },
    diasEtapa:      { rotulo: 'Dias na etapa', desc: true },
    ultimoContato:  { rotulo: 'Último contato', desc: true }
  };

  /** Valor comparável de cada campo. Texto sai normalizado (sem acento). */
  function chaveOrdem(p, campo) {
    if (campo === 'numero') {
      var n = S.numeroProposta(p.contrato);
      return n == null ? -1 : n;
    }
    if (campo === 'valor') return S.numero(p.valor);
    if (campo === 'diasEtapa') return S.diasNaEtapa(p) == null ? -1 : S.diasNaEtapa(p);
    if (campo === 'ultimoContato') return S.diasSemContato(p) == null ? -1 : S.diasSemContato(p);
    if (campo === 'cidade') return S.normalizar(p.cidade) + ' ' + S.normalizar(p.estado);
    if (campo === 'classificacao') return ['Boa', 'Regular', 'Ruim'].indexOf(p.classificacao);
    /* quentes primeiro; as sem temperatura ficam por último */
    if (campo === 'temperatura') return p.temperatura ? S.TEMPERATURAS.indexOf(p.temperatura) : 9;
    if (campo === 'status') return S.STATUS.indexOf(p.status);
    return S.normalizar(p[campo] || '');
  }

  function listaPropostasFiltrada() {
    var lista = S.filtrar(filtrosAtuais({
      busca: el('busca').value,
      status: el('f-status').value,
      classificacao: el('f-classificacao').value,
      estado: el('f-estado').value,
      temperatura: el('f-temperatura').value,
      vendedor: el('f-vendedor').value
    }));
    var campo = ORDENS[estadoUI.ordem.campo] ? estadoUI.ordem.campo : 'numero';
    var desc = estadoUI.ordem.desc;
    lista.sort(function (a, b) {
      var va = chaveOrdem(a, campo), vb = chaveOrdem(b, campo);
      if (va < vb) return desc ? 1 : -1;
      if (va > vb) return desc ? -1 : 1;
      /* empate: o número da proposta decide, sempre do maior para o menor */
      return (S.numeroProposta(b.contrato) || 0) - (S.numeroProposta(a.contrato) || 0);
    });
    return lista;
  }

  function renderBulk() {
    var barra = el('bulk-bar');
    var n = estadoUI.selecao.length;
    barra.hidden = n === 0;
    el('bulk-count').textContent = n + ' selecionada' + (n > 1 ? 's' : '');
    var visiveis = listaPropostasFiltrada().map(function (p) { return p.id; });
    var todas = visiveis.length > 0 && visiveis.every(function (id) { return estadoUI.selecao.indexOf(id) > -1; });
    el('sel-todas').checked = todas;
  }

  function alternarSelecao(idProposta, marcado) {
    var i = estadoUI.selecao.indexOf(idProposta);
    if (marcado && i === -1) estadoUI.selecao.push(idProposta);
    if (!marcado && i > -1) estadoUI.selecao.splice(i, 1);
    renderBulk();
  }

  /** Deixa cabeçalho, seletor e contador falando a mesma coisa. */
  function sincronizarOrdem(lista) {
    var campo = estadoUI.ordem.campo, desc = estadoUI.ordem.desc;

    document.querySelectorAll('#tabela-propostas th[data-sort]').forEach(function (th) {
      var ativo = th.dataset.sort === campo;
      th.classList.toggle('is-sorted', ativo);
      th.classList.toggle('is-desc', ativo && desc);
      th.setAttribute('aria-sort', ativo ? (desc ? 'descending' : 'ascending') : 'none');
    });

    var sel = el('f-ordem');
    var valor = campo + (desc ? ':desc' : ':asc');
    /* status, serviço e classificação só existem no cabeçalho: aí o seletor
       fica sem opção correspondente e é melhor não mostrar nada marcado */
    sel.value = valor;
    if (sel.value !== valor) sel.selectedIndex = -1;

    var nome = (ORDENS[campo] || {}).rotulo || campo;
    var sentido = desc ? '↓' : '↑';
    el('contador-propostas').textContent += ' · ordenado por ' + nome + ' ' + sentido;
    if (lista.length > LIMITE_TABELA) {
      el('contador-propostas').textContent += ' (mostrando as ' + LIMITE_TABELA + ' primeiras)';
    }
  }

  function renderPropostas() {
    var lista = listaPropostasFiltrada();
    var total = lista.reduce(function (s, p) { return s + S.numero(p.valor); }, 0);
    el('contador-propostas').textContent = lista.length + ' proposta(s) · ' + S.moeda(total);

    el('tbody-propostas').innerHTML = lista.length ? lista.slice(0, LIMITE_TABELA).map(function (p) {
      var marcada = estadoUI.selecao.indexOf(p.id) > -1;
      return '<tr data-abrir="' + p.id + '"' + (marcada ? ' class="is-selected"' : '') + '>' +
        '<td class="sel"><input type="checkbox" data-sel="' + p.id + '"' + (marcada ? ' checked' : '') + ' aria-label="Selecionar proposta" /></td>' +
        '<td>' + esc(p.contrato || '—') + seloRevisao(p) + '</td>' +
        '<td><strong>' + esc(p.cliente) + '</strong><br><small style="color:var(--ink-soft)">' + esc(p.contato || '') + '</small></td>' +
        '<td>' + esc([p.cidade, p.estado].filter(Boolean).join('/')) + '</td>' +
        '<td>' + esc(p.servico || '—') + '</td>' +
        '<td class="num">' + S.moeda(p.valor) + '</td>' +
        '<td><span class="tag-pair">' + tagClassificacao(p.classificacao) + tagTemperatura(p.temperatura) + '</span></td>' +
        '<td>' + tagStatus(p.status) + '</td>' +
        '<td class="num">' + (S.diasNaEtapa(p) == null ? '—' : S.diasNaEtapa(p) + 'd') + '</td>' +
        '<td>' + esc(textoContato(p)) + '</td></tr>';
    }).join('') : '<tr><td colspan="10">' + vazio('Nada encontrado com esses filtros.') + '</td></tr>';

    el('cards-propostas').innerHTML = lista.length ? lista.slice(0, 200).map(function (p) {
      return '<article class="card" data-abrir="' + p.id + '">' +
        '<div class="card-top"><span>' + esc(p.contrato || '—') + '</span>' + tagStatus(p.status) + '</div>' +
        '<h3 class="card-title">' + esc(p.cliente) + '</h3>' +
        '<div class="card-top"><span>' + esc([p.cidade, p.estado].filter(Boolean).join('/')) + ' · ' + esc(p.servico || '—') + '</span></div>' +
        '<div class="card-meta"><span class="tag-pair">' + tagClassificacao(p.classificacao) + tagTemperatura(p.temperatura) + '</span>' +
        '<span class="card-value">' + S.moeda(p.valor) + '</span></div>' +
        '<div class="card-top" style="margin-top:6px">último contato: ' + esc(textoContato(p)) + ' · ' + esc(textoEtapa(p)) + '</div></article>';
    }).join('') : vazio('Nada encontrado com esses filtros.');

    sincronizarOrdem(lista);
    renderBulk();
  }

  /* ---------------- follow-up ---------------- */

  function renderFollowup() {
    var lista = S.filtrar(filtrosAtuais({
      vendedor: el('fu-vendedor').value,
      temperatura: el('fu-temperatura').value,
      somenteAbertas: el('fu-somente-abertas').checked
    }));
    if (el('fu-somente-agenda').checked) {
      lista = lista.filter(function (p) { return !!p.proximoContato; });
    }

    var ordem = el('fu-ordem').value;
    lista.sort(function (a, b) {
      if (ordem === 'valor') return S.numero(b.valor) - S.numero(a.valor);
      if (ordem === 'agenda') {
        /* quem tem data marcada vem primeiro, do mais atrasado ao mais distante */
        var da = a.proximoContato, db = b.proximoContato;
        if (da && db) return da.localeCompare(db);
        if (da) return -1;
        if (db) return 1;
      }
      return (S.diasSemContato(b) || 0) - (S.diasSemContato(a) || 0);
    });

    var limite = S.config.diasFollowup;
    var atrasadas = lista.filter(function (p) { return S.urgencia(p) !== 'ok'; });
    var semNenhum = lista.filter(function (p) { return !S.ultimoContato(p); });
    var reunioes = lista.reduce(function (s, p) { return s + S.contarAtividades(p, 'Reunião'); }, 0);
    var ligacoes = lista.reduce(function (s, p) { return s + S.contarAtividades(p, 'Ligação'); }, 0);

    var paraHoje = lista.filter(function (p) { return S.agendaStatus(p) === 'hoje'; });
    var vencidos = lista.filter(function (p) { return S.agendaStatus(p) === 'atrasado'; });
    var naSemana = lista.filter(function (p) { return S.agendaStatus(p) === 'semana'; });

    el('fu-summary').innerHTML =
      '<div class="fu-card fu-card-hoje"><b>' + paraHoje.length + '</b><span>marcados para hoje</span></div>' +
      '<div class="fu-card fu-card-atraso"><b>' + vencidos.length + '</b><span>com data marcada vencida</span></div>' +
      '<div class="fu-card"><b>' + naSemana.length + '</b><span>marcados para os próximos 7 dias</span></div>' +
      '<div class="fu-card"><b>' + atrasadas.length + '</b><span>passaram de ' + limite + ' dias sem contato</span></div>' +
      '<div class="fu-card"><b>' + semNenhum.length + '</b><span>nunca receberam contato registrado</span></div>' +
      '<div class="fu-card"><b>' + ligacoes + ' / ' + reunioes + '</b><span>ligações / reuniões registradas</span></div>';

    var total = lista.length;
    var mostrando = Math.min(estadoUI.fuLimite, total);
    el('fu-list').innerHTML = total ? lista.slice(0, mostrando).map(function (p) {
      var d = S.diasSemContato(p);
      return '<div class="fu-item" data-urg="' + S.urgencia(p) + '">' +
        '<div class="fu-main"><strong>' + esc(p.cliente) + '</strong> ' + tagStatus(p.status) +
        tagTemperatura(p.temperatura) + seloAgenda(p) +
        '<div class="fu-sub"><span>' + esc(p.contrato || '—') + '</span><span>' + esc([p.cidade, p.estado].filter(Boolean).join('/')) + '</span>' +
        '<span>' + S.moeda(p.valor) + '</span><span>' + (d == null ? 'sem data' : d + ' dias sem contato') + '</span>' +
        (p.vendedor ? '<span>' + esc(p.vendedor) + '</span>' : '') + '</div></div>' +
        '<div class="fu-actions">' +
        '<button class="btn btn-ghost btn-sm" data-registrar="Ligação" data-id="' + p.id + '">Ligação hoje</button>' +
        '<button class="btn btn-ghost btn-sm" data-registrar="Reunião" data-id="' + p.id + '">Reunião hoje</button>' +
        '<button class="btn btn-primary btn-sm" data-abrir="' + p.id + '">Abrir</button>' +
        '</div></div>';
    }).join('') : vazio('Tudo em dia por aqui.');

    var maisBox = el('fu-more');
    maisBox.hidden = total === 0;
    el('fu-more-text').textContent = total
      ? 'Exibindo ' + mostrando + ' de ' + total + (mostrando < total ? '' : ' — fim da lista')
      : '';
    el('fu-more-btn').hidden = mostrando >= total;
    el('fu-more-btn').textContent = 'Mostrar mais ' + Math.min(120, total - mostrando);
  }

  /** Selo de agenda no cartão do follow-up. */
  function seloAgenda(p) {
    var st = S.agendaStatus(p);
    if (st === 'sem' || st === 'futuro') {
      return st === 'futuro' ? '<span class="tag tag-agenda">' + S.dataBR(p.proximoContato) + '</span>' : '';
    }
    var rotulos = { hoje: 'contato hoje', atrasado: 'contato vencido ' + S.dataBR(p.proximoContato), semana: S.dataBR(p.proximoContato) };
    return '<span class="tag tag-agenda tag-agenda-' + st + '">' + rotulos[st] + '</span>';
  }

  /* ---------------- equipe ---------------- */

  function renderEquipe() {
    var dias = parseInt(el('eq-janela').value, 10);
    var corte = new Date(Date.now() - dias * 86400000).toISOString().slice(0, 10);
    var lista = S.filtrar(filtrosAtuais());
    var nomes = S.vendedores.slice();
    lista.forEach(function (p) { if (p.vendedor && nomes.indexOf(p.vendedor) === -1) nomes.push(p.vendedor); });
    if (!nomes.length) nomes = ['Sem vendedor'];

    el('tbody-equipe').innerHTML = nomes.map(function (nome) {
      var minhas = lista.filter(function (p) { return (p.vendedor || 'Sem vendedor') === nome; });
      var conta = function (tipo) {
        return minhas.reduce(function (s, p) {
          return s + (p.atividades || []).filter(function (a) { return a.tipo === tipo && (a.data || '') >= corte; }).length;
        }, 0);
      };
      var outros = minhas.reduce(function (s, p) {
        return s + (p.atividades || []).filter(function (a) {
          return ['E-mail', 'WhatsApp', 'Visita', 'Outro'].includes(a.tipo) && (a.data || '') >= corte;
        }).length;
      }, 0);
      var atrasadas = minhas.filter(function (p) { return S.urgencia(p) !== 'ok' && S.STATUS_ABERTOS.includes(p.status); }).length;
      var fechado = minhas.filter(function (p) { return p.status === 'Fechada'; })
        .reduce(function (s, p) { return s + S.numero(p.valor); }, 0);
      return '<tr><td><strong>' + esc(nome) + '</strong></td><td class="num">' + minhas.length + '</td>' +
        '<td class="num">' + conta('Ligação') + '</td><td class="num">' + conta('Reunião') + '</td>' +
        '<td class="num">' + outros + '</td><td class="num">' + atrasadas + '</td>' +
        '<td class="num">' + S.moeda(fechado) + '</td></tr>';
    }).join('');

    var recentes = [];
    lista.forEach(function (p) {
      (p.atividades || []).forEach(function (a) { recentes.push({ p: p, a: a }); });
    });
    recentes.sort(function (x, y) { return S.chaveMomento(y.a).localeCompare(S.chaveMomento(x.a)); });
    el('ultimas-atividades').innerHTML = recentes.length ? recentes.slice(0, 12).map(function (r) {
      return '<div class="mini-row clickable" data-abrir="' + r.p.id + '"><div class="m-main"><strong>' + esc(r.a.tipo) + ' · ' + esc(r.p.cliente) + '</strong>' +
        '<small>' + esc(r.a.responsavel || 'sem responsável') + (r.a.obs ? ' — ' + esc(r.a.obs) : '') + '</small></div>' +
        '<span class="m-val">' + S.dataHoraBR(r.a.data, r.a.hora) + '</span></div>';
    }).join('') : vazio('Nenhuma atividade registrada ainda.');

    if (window.Charts && window.Chart) { Charts.base(); Charts.equipe(lista, S.vendedores.slice(), dias); }
  }

  /* ---------------- relatório semanal ---------------- */

  function preencherSemanas() {
    var sel = el('rel-semana');
    if (sel.options.length) return;
    var itens = [];
    for (var i = 0; i < 12; i++) {
      var ref = new Date();
      ref.setDate(ref.getDate() - i * 7);
      var sem = S.semanaDe(ref.getFullYear() + '-' + ('0' + (ref.getMonth() + 1)).slice(-2) + '-' + ('0' + ref.getDate()).slice(-2));
      var rotulo = S.dataBR(sem.inicio) + ' a ' + S.dataBR(sem.fim);
      if (i === 0) rotulo = 'Esta semana (' + rotulo + ')';
      if (i === 1) rotulo = 'Semana passada (' + rotulo + ')';
      itens.push('<option value="' + sem.inicio + '">' + rotulo + '</option>');
    }
    sel.innerHTML = itens.join('');
  }

  function renderRelatorio() {
    preencherSemanas();
    var sel = el('rel-semana');
    var inicio = estadoUI.relSemana || sel.value || '';
    if (inicio) sel.value = inicio;

    var vend = el('rel-vendedor').value;
    var base = S.propostas.filter(function (p) { return !vend || p.vendedor === vend; });
    var r = S.relatorioSemana(inicio, base);

    el('rel-corpo').innerHTML =
      '<div class="report-head">' +
      '<div><h2>Reunião comercial</h2>' +
      '<p>Semana de ' + S.dataBR(r.inicio) + ' a ' + S.dataBR(r.fim) +
      (vend ? ' · ' + esc(vend) : ' · toda a equipe') + '</p></div>' +
      '<div class="report-brand"><strong>Sammour Engenharia</strong><span>emitido em ' + S.dataBR(S.hojeISO()) + '</span></div>' +
      '</div>' +

      '<div class="report-kpis">' +
      relKpi('Fechadas na semana', r.fechadas.length, S.moeda(r.valorFechado)) +
      relKpi('Perdidas na semana', r.perdidas.length, S.moeda(r.valorPerdido)) +
      relKpi('Propostas novas', r.novas.length, S.moeda(r.valorNovo)) +
      relKpi('Em aberto hoje', r.abertasQtd, S.moeda(r.abertasValor)) +
      '</div>' +

      relSecao('Fechadas', r.fechadas.map(function (f) {
        return relLinha(f.p, S.dataBR(f.data), S.moeda(f.p.valor));
      }), 'Nenhuma proposta fechada nesta semana.') +

      relSecao('Perdidas', r.perdidas.map(function (x) {
        return relLinha(x.p, S.dataBR(x.data) + ' · ' + (x.p.motivoPerda || 'motivo não informado'), S.moeda(x.p.valor));
      }), 'Nenhuma proposta perdida nesta semana.') +
      (Object.keys(r.motivos).length
        ? '<p class="report-note">Motivos: ' + Object.keys(r.motivos).map(function (m) {
            return esc(m) + ' (' + r.motivos[m] + ')';
          }).join(' · ') + '</p>'
        : '') +

      '<div class="report-section"><h3>Esforço e resultado por vendedor</h3>' +
      '<table class="table table-report"><thead><tr><th>Vendedor</th><th class="num">Contatos</th>' +
      '<th class="num">Ligações</th><th class="num">Reuniões</th><th class="num">Fechado</th>' +
      '<th class="num">Agendados</th></tr></thead><tbody>' +
      (r.equipe.length ? r.equipe.map(function (v) {
        return '<tr><td>' + esc(v.vendedor) + '</td><td class="num">' + v.contatos + '</td>' +
          '<td class="num">' + v.ligacoes + '</td><td class="num">' + v.reunioes + '</td>' +
          '<td class="num">' + S.moeda(v.fechado) + '</td><td class="num">' + v.agendados + '</td></tr>';
      }).join('') : '<tr><td colspan="6">Nenhum vendedor cadastrado.</td></tr>') +
      '</tbody></table></div>' +

      relSecao('Agenda: de hoje até ' + S.dataBR(r.proximaFim),
        r.agenda.map(function (p) {
          return relLinha(p, S.dataBR(p.proximoContato) + ' · ' + (p.vendedor || 'sem vendedor'), S.moeda(p.valor));
        }), 'Nenhum contato marcado para os próximos dias.') +

      relSecao('Contatos marcados e já vencidos', r.atrasados.map(function (p) {
        return relLinha(p, 'era ' + S.dataBR(p.proximoContato) + ' · ' + (p.vendedor || 'sem vendedor'), S.moeda(p.valor));
      }), 'Nada vencido.') +

      relSecao('Sem data marcada e passando do prazo', r.semAgenda.slice(0, 15).map(function (p) {
        return relLinha(p, S.diasSemContato(p) + ' dias sem contato · ' + (p.vendedor || 'sem vendedor'), S.moeda(p.valor));
      }), 'Nenhuma proposta nessa situação.') +
      (r.semAgenda.length > 15 ? '<p class="report-note">e mais ' + (r.semAgenda.length - 15) + ' propostas na mesma situação.</p>' : '');
  }

  /** Rótulo legível do filtro de período do topo. */
  function rotuloPeriodo() {
    var sel = el('filtro-periodo');
    var op = sel && sel.options[sel.selectedIndex];
    return op ? op.textContent.trim() : 'todo o período';
  }

  /** Planilha das obras fechadas: base completa + serviços + resumos. */
  function exportarObrasFechadas() {
    var vend = el('rel-vendedor').value;
    var escopo = el('rel-escopo-fechadas').value;
    var lista, texto;

    if (escopo === 'semana') {
      var inicio = estadoUI.relSemana || el('rel-semana').value || '';
      var base = S.propostas.filter(function (p) { return !vend || p.vendedor === vend; });
      var r = S.relatorioSemana(inicio, base);
      lista = r.fechadas.map(function (f) { return f.p; });
      texto = 'fechadas entre ' + S.dataBR(r.inicio) + ' e ' + S.dataBR(r.fim);
    } else if (escopo === 'tudo') {
      lista = S.propostas.filter(function (p) { return !vend || p.vendedor === vend; });
      texto = 'todas as obras fechadas na base';
    } else {
      lista = S.filtrar(filtrosAtuais({ vendedor: vend, status: 'Fechada' }));
      texto = rotuloPeriodo() + ' (pela data da proposta)';
    }

    var n = I.exportarObrasFechadas(lista, { escopo: texto, vendedor: vend });
    toast(n ? n + ' obra' + (n > 1 ? 's' : '') + ' fechada' + (n > 1 ? 's' : '') + ' na planilha.'
            : 'Nenhuma obra fechada nesse recorte.');
  }

  function relKpi(rotulo, qtd, valor) {
    return '<div class="report-kpi"><span>' + esc(rotulo) + '</span><b>' + qtd + '</b><small>' + valor + '</small></div>';
  }

  function relSecao(titulo, linhas, vazioTexto) {
    return '<div class="report-section"><h3>' + esc(titulo) + ' <span class="report-count">' + linhas.length + '</span></h3>' +
      (linhas.length ? '<ul class="report-list">' + linhas.join('') + '</ul>'
        : '<p class="report-empty">' + esc(vazioTexto) + '</p>') + '</div>';
  }

  function relLinha(p, meio, direita) {
    return '<li><span class="rl-cli">' + esc(p.cliente || 'sem cliente') + '</span>' +
      '<span class="rl-meta">' + esc(p.contrato || '—') + ' · ' + esc(p.servico || 'serviço não informado') +
      ' · ' + esc(meio) + '</span>' +
      '<span class="rl-val">' + direita + '</span></li>';
  }

  /* ---------------- ajustes ---------------- */

  function renderConfig() {
    el('cfg-meta-propostas').value = S.config.metaPropostas;
    el('cfg-meta-valor').value = S.valorCampo(S.config.metaValor);
    el('cfg-dias-followup').value = S.config.diasFollowup;
    el('lista-vendedores').innerHTML = S.vendedores.length ? S.vendedores.map(function (v) {
      return '<span class="chip">' + esc(v) + '<button data-remover-vendedor="' + esc(v) + '" aria-label="Remover">✕</button></span>';
    }).join('') : '<p class="empty">Nenhum vendedor cadastrado.</p>';
  }

  /* ---------------- drawer da proposta ---------------- */

  function abrirProposta(idProposta) {
    var p = S.propostas.find(function (x) { return x.id === idProposta; });
    if (!p) return;
    estadoUI.propostaAberta = idProposta;
    el('drawer-contrato').innerHTML = esc(p.contrato || 'Sem contrato') + (p.revisao ? ' · Rev.' + String(p.revisao).padStart(2, '0') : '');
    el('drawer-cliente').textContent = p.cliente || 'Sem cliente';
    el('drawer-body').innerHTML = corpoDrawer(p);
    el('drawer').hidden = false;
    el('drawer-backdrop').hidden = false;
    document.body.style.overflow = 'hidden';
  }

  /** Só pergunta se existe rascunho com algo digitado; devolve false para cancelar a saída. */
  function podeDescartarRascunho() {
    if (!estadoUI.rascunho || !estadoUI.rascunhoTocado) return true;
    return confirm('A nova proposta ainda não foi confirmada.\n\nSe sair agora os dados preenchidos serão descartados. Tem certeza que deseja sair?');
  }

  /** forcar === true pula o aviso (usado depois que o usuário já confirmou a saída). */
  function fecharDrawer(forcar) {
    if (forcar !== true && !podeDescartarRascunho()) return;
    el('drawer').hidden = true;
    el('drawer-backdrop').hidden = true;
    document.body.style.overflow = '';
    estadoUI.propostaAberta = null;
    estadoUI.rascunho = null;
    estadoUI.rascunhoTocado = false;
  }

  function corpoDrawer(p) {
    var vendedores = [''].concat(S.vendedores);
    var atividades = (p.atividades || []).slice().sort(function (a, b) { return S.chaveMomento(b).localeCompare(S.chaveMomento(a)); });

    var etapas = (p.historicoStatus || []).slice().reverse();
    return '' +
      '<div class="dsection"><h3>Situação</h3>' +
      '<p class="panel-text">' + esc(textoEtapa(p) || 'sem data de entrada na etapa') +
      ' · último contato ' + esc(textoContato(p, true)) + '</p>' +
      '<div class="dgrid">' +
      campoSelect('status', 'Status', S.STATUS, p.status) +
      campoSelect('classificacao', 'Classificação', S.CLASSIFICACOES, p.classificacao) +
      campoSelect('temperatura', 'Temperatura', listaTemperaturas(), p.temperatura) +
      campoSelect('vendedor', 'Vendedor responsável', vendedores, p.vendedor) +
      campoValor(p.valor) +
      '</div>' +
      (p.status === 'Perdida'
        ? '<div class="dgrid">' + campoSelect('motivoPerda', 'Motivo da perda', [''].concat(S.MOTIVOS_PERDA), p.motivoPerda) + '</div>' +
          (p.motivoPerda ? '' : '<p class="panel-text alerta">Informe o motivo — é o que alimenta o relatório de perdas.</p>')
        : '') +
      (S.STATUS_ABERTOS.indexOf(p.status) > -1
        ? '<div class="dgrid">' +
          campoTexto('proximoContato', 'Próximo contato em', p.proximoContato, 'date') +
          '<div class="field"><span>&nbsp;</span><div class="btn-row-sm">' +
          '<button class="btn btn-ghost btn-sm" data-agendar="1">+1 dia</button>' +
          '<button class="btn btn-ghost btn-sm" data-agendar="7">+1 semana</button>' +
          '<button class="btn btn-ghost btn-sm" data-agendar="15">+15 dias</button>' +
          '</div></div></div>' +
          textoAgenda(p)
        : '') +
      '</div>' +

      '<div class="dsection"><h3>Registrar contato</h3>' +
      '<div class="dgrid">' +
      '<label class="field"><span>Data do contato</span>' +
      '<input class="input" type="date" id="data-atividade" value="' + esc(S.hojeISO()) + '" max="' + esc(S.hojeISO()) + '" /></label>' +
      '<label class="field"><span>Horário</span>' +
      '<input class="input" type="time" id="hora-atividade" value="' + esc(S.agoraHora()) + '" /></label>' +
      '</div>' +
      '<p class="panel-text" style="margin:2px 0 10px">Vem preenchido com agora. Ajuste antes de clicar no tipo de contato para lançar um atendimento anterior.</p>' +
      '<div class="quick-acts">' +
      S.TIPOS_ATIVIDADE.map(function (t) {
        return '<button class="btn btn-ghost btn-sm" data-registrar="' + t + '" data-id="' + p.id + '">' + t + '</button>';
      }).join('') + '</div>' +
      '<label class="field"><span>Observação do próximo contato (opcional)</span>' +
      '<input class="input" id="obs-atividade" placeholder="Ex.: cliente pediu revisão do escopo" /></label></div>' +

      '<div class="dsection"><h3>Etapas do funil</h3><div class="timeline">' +
      etapas.map(function (h) {
        return '<div class="tl-item"><div class="tl-dot"></div><div class="tl-body">' +
          '<strong>' + esc(h.status) + '</strong> <span class="tl-meta">' + S.dataBR(h.data) + '</span></div></div>';
      }).join('') + '</div></div>' +

      '<div class="dsection"><h3>Histórico de contatos (' + atividades.length + ')</h3><div class="timeline">' +
      (atividades.length ? atividades.map(function (a) {
        return '<div class="tl-item"><div class="tl-dot"></div><div class="tl-body">' +
          '<strong>' + esc(a.tipo) + '</strong> <span class="tl-meta">' + S.dataHoraBR(a.data, a.hora) + (a.responsavel ? ' · ' + esc(a.responsavel) : '') + '</span>' +
          (a.obs ? '<p>' + esc(a.obs) + '</p>' : '') +
          '<button class="btn btn-ghost btn-sm" style="margin-top:6px" data-excluir-atividade="' + a.id + '">Remover</button>' +
          '</div></div>';
      }).join('') : '<p class="empty">Nenhum contato registrado.</p>') + '</div></div>' +

      '<div class="dsection"><h3>Cliente</h3><div class="dgrid">' +
      campoTexto('cliente', 'Cliente', p.cliente) +
      campoTexto('cnpj', 'CNPJ', p.cnpj) +
      campoTexto('contato', 'Contato', p.contato) +
      campoTexto('telefone', 'Telefone', p.telefone) +
      campoTexto('email', 'E-mail', p.email) +
      campoTexto('cidade', 'Cidade', p.cidade) +
      campoTexto('estado', 'UF', p.estado) +
      campoSelect('tipoCliente', 'Tipo de cliente', S.TIPOS_CLIENTE, p.tipoCliente || 'NOVO') +
      campoServico(p.servico) +
      '</div></div>' +

      '<div class="dsection"><h3>Proposta</h3>' +
      campoTexto('contrato', 'Contrato', p.contrato) +
      campoTexto('dataProposta', 'Data da proposta', p.dataProposta, 'date') +
      campoTexto('obra', 'Obra', p.obra) +
      campoTexto('descricao', 'Descrição', p.descricao) +
      '<label class="field"><span>Observações internas</span><textarea class="input" rows="3" data-campo="observacoes">' + esc(p.observacoes || '') + '</textarea></label>' +
      '</div>' +

      '<div class="btn-row"><button class="btn btn-ghost" id="btn-ligar-cliente">Ligar</button>' +
      '<button class="btn btn-ghost" id="btn-email-cliente">Enviar e-mail</button>' +
      '<button class="btn btn-danger" id="btn-excluir-proposta">Excluir proposta</button></div>';
  }

  function campoTexto(campo, rotulo, valor, tipo) {
    return '<label class="field"><span>' + esc(rotulo) + '</span>' +
      '<input class="input" type="' + (tipo || 'text') + '" data-campo="' + campo + '" value="' + esc(valor == null ? '' : valor) + '" /></label>';
  }

  /** Valor aceita "1.250.000" e "1250000,50"; é reexibido formatado ao sair do campo. */
  function campoValor(valor) {
    return '<label class="field"><span>Valor (R$)</span>' +
      '<input class="input" type="text" inputmode="decimal" data-campo="valor" ' +
      'placeholder="0" value="' + esc(S.valorCampo(valor)) + '" /></label>';
  }

  function emDias(dias) {
    var d = new Date();
    d.setDate(d.getDate() + dias);
    return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  }

  function textoAgenda(p) {
    var d = S.diasParaProximo(p);
    if (d == null) return '<p class="panel-text">Sem próximo contato marcado — a proposta só aparece no follow-up pelo tempo sem contato.</p>';
    var quando = d === 0 ? 'hoje' : (d < 0 ? 'atrasado há ' + (-d) + ' dia(s)' : 'em ' + d + ' dia(s)');
    return '<p class="panel-text' + (d <= 0 ? ' alerta' : '') + '">Próximo contato ' + quando +
      ' (' + S.dataBR(p.proximoContato) + '). Ao registrar um contato nessa data ou depois, a marcação é baixada automaticamente.</p>';
  }

  /** Serviço: lista fixa da empresa, mantendo o que veio da planilha e permitindo digitar um caso novo. */
  function campoServico(valor) {
    var atual = String(valor || '').trim();
    var lista = S.SERVICOS.slice();
    var foraDaLista = atual && lista.indexOf(atual) === -1;
    if (foraDaLista) lista.push(atual);
    return '<label class="field"><span>Serviço</span>' +
      '<select class="input" id="sel-servico" data-campo="servico">' +
      '<option value=""' + (atual ? '' : ' selected') + '>— selecionar —</option>' +
      opcoes(lista, atual) +
      '<option value="__outro__">Outro (digitar)…</option>' +
      '</select>' +
      '<input class="input" id="txt-servico" data-campo="servico" hidden style="margin-top:6px" ' +
      'placeholder="Descreva o serviço" value="" /></label>';
  }

  function campoSelect(campo, rotulo, lista, valor) {
    return '<label class="field"><span>' + esc(rotulo) + '</span>' +
      '<select class="input" data-campo="' + campo + '">' + opcoes(lista, valor) + '</select></label>';
  }

  function salvarCampoDrawer(elemento) {
    var campo = elemento.dataset.campo;
    if (!campo || !estadoUI.propostaAberta) return;
    var valor = elemento.value;
    if (campo === 'servico' && valor === '__outro__') {
      var txt = el('txt-servico');
      if (txt) { txt.hidden = false; txt.value = ''; txt.focus(); }
      return;
    }
    if (campo === 'valor') {
      valor = S.numero(valor);
      elemento.value = S.valorCampo(valor);
    }
    if (campo === 'estado') valor = String(valor).toUpperCase().slice(0, 2);
    if (campo === 'servico') {
      valor = String(valor).toUpperCase().trim();
      if (elemento.id === 'sel-servico' && el('txt-servico')) el('txt-servico').hidden = true;
    }
    var alteracao = {};
    alteracao[campo] = valor;
    S.atualizar(estadoUI.propostaAberta, alteracao);
    /* Perdida mostra o motivo; encerrar tira a proposta da agenda — o drawer precisa refletir isso */
    if (campo === 'status') { abrirProposta(estadoUI.propostaAberta); renderizarView(estadoUI.view); return; }
    if (campo === 'motivoPerda' || campo === 'proximoContato') {
      abrirProposta(estadoUI.propostaAberta); renderizarView(estadoUI.view); return;
    }
    if (campo === 'cliente') el('drawer-cliente').textContent = valor || 'Sem cliente';
    if (campo === 'contrato') el('drawer-contrato').textContent = valor || 'Sem contrato';
    renderizarView(estadoUI.view);
  }

  /* ---------------- selects dinâmicos ---------------- */

  function preencherSelects() {
    var ufs = Array.from(new Set(S.propostas.map(function (p) { return p.estado; }).filter(Boolean))).sort();
    var vendedores = S.vendedores.slice();
    S.propostas.forEach(function (p) { if (p.vendedor && vendedores.indexOf(p.vendedor) === -1) vendedores.push(p.vendedor); });

    function preencher(id, itens, rotuloVazio) {
      var sel = el(id);
      if (!sel) return;
      var atual = sel.value;
      sel.innerHTML = '<option value="">' + rotuloVazio + '</option>' + opcoes(itens);
      sel.value = itens.indexOf(atual) > -1 ? atual : '';
    }
    preencher('f-status', S.STATUS, 'Status: todos');
    preencher('f-estado', ufs, 'UF: todas');
    preencher('f-vendedor', vendedores, 'Vendedor: todos');
    preencher('funil-vendedor', vendedores, 'Todos os vendedores');
    preencher('fu-vendedor', vendedores, 'Todos os vendedores');
    preencher('rel-vendedor', vendedores, 'Todos os vendedores');
    preencherPeriodos();
  }

  /** Períodos fixos + um item por ano encontrado nas propostas (o ano vem do nº do contrato). */
  function preencherPeriodos() {
    var sel = el('filtro-periodo');
    var anos = S.anosComPropostas();
    var html = '<option value="tudo">Todo o período</option>' +
      '<option value="7">Últimos 7 dias</option>' +
      '<option value="30">Últimos 30 dias</option>' +
      '<option value="90">Últimos 90 dias</option>' +
      anos.map(function (a) {
        return '<option value="ano:' + a.ano + '">' + a.ano + ' (' + a.qtd + ')</option>';
      }).join('');
    if (sel.innerHTML === html) return;
    sel.innerHTML = html;
    /* mantém a escolha; se o ano sumiu da base, volta para todo o período */
    var existe = Array.prototype.some.call(sel.options, function (o) { return o.value === estadoUI.periodo; });
    if (!existe) estadoUI.periodo = 'tudo';
    sel.value = estadoUI.periodo;
  }

  /* ---------------- eventos globais ---------------- */

  function ligarEventos() {
    document.querySelectorAll('.nav-item, .tab, .aviso-vazio [data-view]').forEach(function (b) {
      b.addEventListener('click', function () { mostrarView(b.dataset.view); });
    });

    el('filtro-periodo').addEventListener('change', function (e) {
      estadoUI.periodo = e.target.value;
      renderizarView(estadoUI.view);
    });

    ['btn-nova-proposta', 'btn-nova-proposta-top'].forEach(function (id) {
      var b = el(id);
      if (b) b.addEventListener('click', criarProposta);
    });

    // filtros
    ['busca', 'f-status', 'f-classificacao', 'f-estado', 'f-temperatura', 'f-vendedor'].forEach(function (id) {
      el(id).addEventListener('input', renderPropostas);
      el(id).addEventListener('change', renderPropostas);
    });
    ['busca-funil', 'funil-vendedor'].forEach(function (id) {
      el(id).addEventListener('input', renderFunil);
      el(id).addEventListener('change', renderFunil);
    });
    ['fu-vendedor', 'fu-temperatura', 'fu-ordem', 'fu-somente-abertas', 'fu-somente-agenda'].forEach(function (id) {
      el(id).addEventListener('change', function () { estadoUI.fuLimite = 120; renderFollowup(); });
    });
    el('fu-more-btn').addEventListener('click', function () {
      estadoUI.fuLimite += 120;
      renderFollowup();
    });
    el('ch-estado-modo').addEventListener('change', renderPainel);
    el('eq-janela').addEventListener('change', renderEquipe);
    el('rel-semana').addEventListener('change', function (e) {
      estadoUI.relSemana = e.target.value;
      renderRelatorio();
    });
    el('rel-vendedor').addEventListener('change', renderRelatorio);
    el('rel-imprimir').addEventListener('click', function () { window.print(); });
    el('rel-exportar-fechadas').addEventListener('click', exportarObrasFechadas);

    // ordenação da tabela
    document.querySelectorAll('#tabela-propostas th[data-sort]').forEach(function (th) {
      function ordenar() {
        var campo = th.dataset.sort;
        if (estadoUI.ordem.campo === campo) estadoUI.ordem.desc = !estadoUI.ordem.desc;
        else estadoUI.ordem = { campo: campo, desc: !!(ORDENS[campo] || {}).desc };
        renderPropostas();
      }
      th.addEventListener('click', ordenar);
      th.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); ordenar(); }
      });
    });

    el('f-ordem').addEventListener('change', function () {
      var partes = el('f-ordem').value.split(':');
      estadoUI.ordem = { campo: partes[0], desc: partes[1] === 'desc' };
      renderPropostas();
    });

    // seleção múltipla
    document.addEventListener('change', function (e) {
      var cx = e.target.closest && e.target.closest('[data-sel]');
      if (cx) { alternarSelecao(cx.dataset.sel, cx.checked); renderPropostas(); }
    });
    document.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('[data-sel]')) e.stopPropagation();
    }, true);

    el('sel-todas').addEventListener('change', function (e) {
      var visiveis = listaPropostasFiltrada().map(function (p) { return p.id; });
      if (e.target.checked) {
        visiveis.forEach(function (id) { if (estadoUI.selecao.indexOf(id) === -1) estadoUI.selecao.push(id); });
      } else {
        estadoUI.selecao = estadoUI.selecao.filter(function (id) { return visiveis.indexOf(id) === -1; });
      }
      renderPropostas();
    });

    el('bulk-status').innerHTML = opcoes(S.STATUS, 'Enviada');
    el('bulk-motivo').innerHTML = '<option value="">Motivo da perda…</option>' + opcoes(S.MOTIVOS_PERDA, '');
    el('bulk-status').addEventListener('change', function () {
      el('bulk-motivo').hidden = el('bulk-status').value !== 'Perdida';
    });
    el('bulk-aplicar').addEventListener('click', function () {
      var novo = el('bulk-status').value;
      var motivo = el('bulk-motivo').value;
      var n = estadoUI.selecao.length;
      if (!n) return;
      if (novo === 'Perdida' && !motivo) { toast('Escolha o motivo da perda.'); return; }
      estadoUI.selecao.forEach(function (id) {
        S.atualizar(id, novo === 'Perdida' ? { status: novo, motivoPerda: motivo } : { status: novo });
      });
      estadoUI.selecao = [];
      renderTudo();
      toast(n + ' proposta(s) marcada(s) como ' + novo + (novo === 'Perdida' ? ' (' + motivo + ')' : '') + '.');
    });
    el('bulk-temperatura').innerHTML = opcoes(listaTemperaturas(), 'Quente');
    el('bulk-temp-aplicar').addEventListener('click', function () {
      var nova = el('bulk-temperatura').value;
      var n = estadoUI.selecao.length;
      if (!n) return;
      estadoUI.selecao.forEach(function (id) { S.atualizar(id, { temperatura: nova }); });
      estadoUI.selecao = [];
      renderTudo();
      toast(n + ' proposta(s) marcada(s) como ' + (nova || 'sem temperatura') + '.');
    });

    el('bulk-excluir').addEventListener('click', function () {
      var ids = estadoUI.selecao.slice();
      if (!ids.length) return;
      var alvo = S.propostas.filter(function (p) { return ids.indexOf(p.id) > -1; });
      var valor = alvo.reduce(function (t, p) { return t + S.numero(p.valor); }, 0);
      var exemplos = alvo.slice(0, 3).map(function (p) { return p.cliente || 'sem cliente'; }).join(', ');
      if (alvo.length > 3) exemplos += ' e mais ' + (alvo.length - 3);
      var aviso = 'Excluir ' + alvo.length + ' proposta(s)?\n\n' + exemplos +
        '\nValor somado: ' + S.moeda(valor) +
        '\n\nA exclusão apaga também o histórico de contatos e não pode ser desfeita.';
      if (!confirm(aviso)) return;
      var n = S.removerVarios(ids);
      estadoUI.selecao = [];
      if (estadoUI.propostaAberta && ids.indexOf(estadoUI.propostaAberta) > -1) fecharDrawer();
      renderTudo();
      toast(n + ' proposta(s) excluída(s).');
    });

    el('bulk-limpar').addEventListener('click', function () {
      estadoUI.selecao = [];
      renderPropostas();
    });

    el('btn-exportar-csv').addEventListener('click', function () {
      if (!I.exportarCSV(listaPropostasFiltrada())) toast('Nada para exportar.');
    });

    // cliques delegados: abrir proposta e registrar atividade
    document.addEventListener('click', function (e) {
      var registrar = e.target.closest('[data-registrar]');
      if (registrar) {
        e.stopPropagation();
        // os campos de data/hora só existem no drawer; os botões do Follow-up registram agora
        var noDrawer = !!registrar.closest('#drawer') && estadoUI.propostaAberta === registrar.dataset.id;
        var dataInput = noDrawer ? el('data-atividade') : null;
        var horaInput = noDrawer ? el('hora-atividade') : null;
        var obsInput = noDrawer ? el('obs-atividade') : null;

        var data = (dataInput && dataInput.value) || S.hojeISO();
        var hora = (horaInput && horaInput.value) || S.agoraHora();
        if (data > S.hojeISO()) { toast('A data do contato não pode estar no futuro.'); return; }

        var p = S.propostas.find(function (x) { return x.id === registrar.dataset.id; });
        S.registrarAtividade(registrar.dataset.id, {
          tipo: registrar.dataset.registrar,
          data: data,
          hora: hora,
          responsavel: (p && p.vendedor) || '',
          obs: obsInput ? obsInput.value.trim() : ''
        });
        toast(registrar.dataset.registrar + ' registrada em ' + S.dataHoraBR(data, hora) + '.');
        if (estadoUI.propostaAberta === registrar.dataset.id) abrirProposta(registrar.dataset.id);
        renderizarView(estadoUI.view);
        return;
      }
      var excluirAtiv = e.target.closest('[data-excluir-atividade]');
      if (excluirAtiv && estadoUI.propostaAberta) {
        S.removerAtividade(estadoUI.propostaAberta, excluirAtiv.dataset.excluirAtividade);
        abrirProposta(estadoUI.propostaAberta);
        renderizarView(estadoUI.view);
        return;
      }
      if (e.target.closest('[data-sel]')) return;
      var abrir = e.target.closest('[data-abrir]');
      if (abrir) { abrirProposta(abrir.dataset.abrir); return; }

      var removerVend = e.target.closest('[data-remover-vendedor]');
      if (removerVend) {
        var nome = removerVend.dataset.removerVendedor;
        S.estado.vendedores = S.vendedores.filter(function (v) { return v !== nome; });
        S.salvar(); renderConfig(); preencherSelects();
        return;
      }
    });

    // avisa se a página for fechada/recarregada com um rascunho preenchido
    window.addEventListener('beforeunload', function (e) {
      if (estadoUI.rascunho && estadoUI.rascunhoTocado) { e.preventDefault(); e.returnValue = ''; }
    });

    // drawer
    el('drawer-close').addEventListener('click', fecharDrawer);
    el('drawer-backdrop').addEventListener('click', fecharDrawer);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') fecharDrawer(); });
    el('drawer-body').addEventListener('input', function (e) {
      if (e.target.dataset.rascunho) estadoUI.rascunhoTocado = true;
    });
    el('drawer-body').addEventListener('change', function (e) {
      if (e.target.dataset.rascunho && estadoUI.rascunho) {
        estadoUI.rascunhoTocado = true;
        salvarCampoRascunho(e.target);
        return;
      }
      if (e.target.dataset.campo) salvarCampoDrawer(e.target);
    });
    el('drawer-body').addEventListener('click', function (e) {
      if (estadoUI.rascunho) {
        if (e.target.id === 'btn-confirmar-rascunho') confirmarRascunho();
        else if (e.target.id === 'btn-cancelar-rascunho') fecharDrawer();
        return;
      }
      var p = S.propostas.find(function (x) { return x.id === estadoUI.propostaAberta; });
      if (!p) return;
      var agendar = e.target.closest('[data-agendar]');
      if (agendar) {
        var dias = parseInt(agendar.dataset.agendar, 10) || 0;
        S.atualizar(p.id, { proximoContato: emDias(dias) });
        abrirProposta(p.id);
        renderizarView(estadoUI.view);
        toast('Próximo contato marcado para ' + S.dataBR(emDias(dias)) + '.');
        return;
      }
      if (e.target.id === 'btn-ligar-cliente') {
        if (p.telefone) window.location.href = 'tel:' + p.telefone.replace(/[^\d+]/g, '');
        else toast('Sem telefone cadastrado.');
      }
      if (e.target.id === 'btn-email-cliente') {
        if (p.email) window.location.href = 'mailto:' + p.email + '?subject=' + encodeURIComponent('Proposta ' + (p.contrato || ''));
        else toast('Sem e-mail cadastrado.');
      }
      if (e.target.id === 'btn-excluir-proposta') {
        if (confirm('Excluir a proposta de ' + p.cliente + '? Esta ação não pode ser desfeita.')) {
          S.remover(p.id); fecharDrawer(); renderTudo(); toast('Proposta excluída.');
        }
      }
    });

    ligarImportacoes();
    ligarConfig();
  }

  /* ---------------- nova proposta (rascunho) ----------------
     Nada é gravado enquanto o usuário não clica em "Confirmar e criar":
     o formulário vive só em estadoUI.rascunho. */

  function criarProposta() {
    if (!podeDescartarRascunho()) return;
    estadoUI.propostaAberta = null;
    estadoUI.rascunhoTocado = false;
    estadoUI.rascunho = {
      contrato: '', cliente: '', cnpj: '', contato: '', telefone: '', email: '',
      cidade: '', estado: '', servico: '', obra: '', descricao: '', observacoes: '',
      valor: '', status: 'Nova', classificacao: 'Regular', temperatura: '', tipoCliente: 'NOVO',
      vendedor: '', dataProposta: S.hojeISO()
    };
    abrirRascunho();
  }

  function abrirRascunho() {
    el('drawer-contrato').textContent = 'Nova proposta';
    el('drawer-cliente').textContent = 'Preencha e confirme';
    el('drawer-body').innerHTML = corpoRascunho(estadoUI.rascunho);
    el('drawer').hidden = false;
    el('drawer-backdrop').hidden = false;
    document.body.style.overflow = 'hidden';
    var primeiro = el('drawer-body').querySelector('[data-rascunho="cliente"]');
    if (primeiro) primeiro.focus();
  }

  function rTexto(campo, rotulo, valor, tipo) {
    return '<label class="field"><span>' + esc(rotulo) + '</span>' +
      '<input class="input" type="' + (tipo || 'text') + '" data-rascunho="' + campo + '" ' +
      'value="' + esc(valor == null ? '' : valor) + '" /></label>';
  }

  function rSelect(campo, rotulo, lista, valor) {
    return '<label class="field"><span>' + esc(rotulo) + '</span>' +
      '<select class="input" data-rascunho="' + campo + '">' + opcoes(lista, valor) + '</select></label>';
  }

  function rServico(valor) {
    var atual = String(valor || '').trim();
    var lista = S.SERVICOS.slice();
    if (atual && lista.indexOf(atual) === -1) lista.push(atual);
    return '<label class="field"><span>Serviço</span>' +
      '<select class="input" id="rsel-servico" data-rascunho="servico">' +
      '<option value=""' + (atual ? '' : ' selected') + '>— selecionar —</option>' +
      opcoes(lista, atual) +
      '<option value="__outro__">Outro (digitar)…</option>' +
      '</select>' +
      '<input class="input" id="rtxt-servico" data-rascunho="servico" hidden style="margin-top:6px" ' +
      'placeholder="Descreva o serviço" value="" /></label>';
  }

  function corpoRascunho(r) {
    var vendedores = [''].concat(S.vendedores);
    return '' +
      '<div class="dsection"><h3>Cliente</h3><div class="dgrid">' +
      rTexto('cliente', 'Cliente *', r.cliente) +
      rTexto('cnpj', 'CNPJ', r.cnpj) +
      rTexto('contato', 'Contato', r.contato) +
      rTexto('telefone', 'Telefone', r.telefone) +
      rTexto('email', 'E-mail', r.email) +
      rTexto('cidade', 'Cidade', r.cidade) +
      rTexto('estado', 'UF', r.estado) +
      rSelect('tipoCliente', 'Tipo de cliente', S.TIPOS_CLIENTE, r.tipoCliente) +
      '</div>' +
      '<p class="panel-text">Tipo de cliente: NOVO para quem nunca comprou da empresa, ANTIGO para quem já é da carteira. É a coluna "Tipo de cliente" da exportação.</p>' +
      '</div>' +

      '<div class="dsection"><h3>Proposta</h3><div class="dgrid">' +
      rTexto('contrato', 'Contrato', r.contrato) +
      rTexto('dataProposta', 'Data da proposta', r.dataProposta, 'date') +
      rServico(r.servico) +
      '<label class="field"><span>Valor (R$)</span>' +
      '<input class="input" type="text" inputmode="decimal" data-rascunho="valor" placeholder="0" ' +
      'value="' + esc(r.valor == null ? '' : r.valor) + '" /></label>' +
      rSelect('status', 'Status', S.STATUS, r.status) +
      rSelect('classificacao', 'Classificação', S.CLASSIFICACOES, r.classificacao) +
      rSelect('temperatura', 'Temperatura', listaTemperaturas(), r.temperatura) +
      rSelect('vendedor', 'Vendedor responsável', vendedores, r.vendedor) +
      '</div>' +
      rTexto('obra', 'Obra', r.obra) +
      rTexto('descricao', 'Descrição', r.descricao) +
      '<label class="field"><span>Observações internas</span>' +
      '<textarea class="input" rows="3" data-rascunho="observacoes">' + esc(r.observacoes || '') + '</textarea></label>' +
      '</div>' +

      '<p class="panel-text">Nada é salvo até você clicar em confirmar.</p>' +
      '<div class="btn-row">' +
      '<button class="btn btn-primary" id="btn-confirmar-rascunho">Confirmar e criar proposta</button>' +
      '<button class="btn btn-ghost" id="btn-cancelar-rascunho">Cancelar</button>' +
      '</div>';
  }

  /** Lê o formulário direto do DOM — não depende de o change ter disparado antes do clique. */
  function lerRascunho() {
    var r = estadoUI.rascunho;
    if (!r) return null;
    el('drawer-body').querySelectorAll('[data-rascunho]').forEach(function (campo) {
      var nome = campo.dataset.rascunho;
      if (nome === 'servico') {
        var txt = el('rtxt-servico');
        if (txt && !txt.hidden && txt.value.trim()) { r.servico = txt.value; return; }
        if (campo.id === 'rsel-servico' && campo.value !== '__outro__') r.servico = campo.value;
        return;
      }
      r[nome] = campo.value;
    });
    return r;
  }

  function salvarCampoRascunho(elemento) {
    var campo = elemento.dataset.rascunho;
    if (campo === 'servico' && elemento.id === 'rsel-servico' && elemento.value === '__outro__') {
      var txt = el('rtxt-servico');
      if (txt) { txt.hidden = false; txt.value = ''; txt.focus(); }
      return;
    }
    if (campo === 'servico' && elemento.id === 'rsel-servico' && el('rtxt-servico')) {
      el('rtxt-servico').hidden = true;
    }
    if (campo === 'valor') elemento.value = S.valorCampo(S.numero(elemento.value));
    if (campo === 'estado') elemento.value = String(elemento.value).toUpperCase().slice(0, 2);
    estadoUI.rascunho[campo] = elemento.value;
  }

  function confirmarRascunho() {
    var r = lerRascunho();
    if (!r) return;
    if (!String(r.cliente || '').trim()) {
      toast('Informe o nome do cliente para criar a proposta.');
      var alvo = el('drawer-body').querySelector('[data-rascunho="cliente"]');
      if (alvo) alvo.focus();
      return;
    }
    S.adicionar({
      contrato: String(r.contrato || '').trim(),
      cliente: String(r.cliente || '').trim().toUpperCase(),
      cnpj: String(r.cnpj || '').trim(),
      contato: String(r.contato || '').trim(),
      telefone: String(r.telefone || '').trim(),
      email: String(r.email || '').trim(),
      cidade: String(r.cidade || '').trim(),
      estado: String(r.estado || '').trim().toUpperCase().slice(0, 2),
      servico: String(r.servico || '').trim().toUpperCase(),
      obra: String(r.obra || '').trim(),
      descricao: String(r.descricao || '').trim(),
      observacoes: String(r.observacoes || '').trim(),
      valor: S.numero(r.valor),
      status: r.status || 'Nova',
      classificacao: r.classificacao || 'Regular',
      temperatura: r.temperatura || '',
      tipoCliente: r.tipoCliente === 'ANTIGO' ? 'ANTIGO' : 'NOVO',
      vendedor: String(r.vendedor || '').trim(),
      dataProposta: r.dataProposta || S.hojeISO()
    });
    var novo = S.propostas[S.propostas.length - 1];
    estadoUI.rascunho = null;
    estadoUI.rascunhoTocado = false;
    renderTudo();
    abrirProposta(novo.id);
    toast('Proposta criada.');
  }

  /* ---------------- importações ---------------- */

  function ligarImportacoes() {
    el('in-xlsx').addEventListener('change', function (e) {
      var arq = e.target.files[0];
      if (!arq) return;
      el('log-xlsx').innerHTML = '';
      logar('log-xlsx', 'Lendo ' + arq.name + '...');
      I.lerPlanilha(arq, function () { renderTudo(); toast('Planilha importada.'); },
        function (m) { logar('log-xlsx', m); });
      e.target.value = '';
    });

    function importarPdfs(e) {
      var arquivos = e.target.files;
      if (!arquivos || !arquivos.length) return;
      el('log-pdf').innerHTML = '';
      el('pdf-progress').hidden = false;
      I.processarPdfs(arquivos,
        function (pct, nome) {
          el('pdf-progress-bar').style.width = Math.round(pct * 100) + '%';
        },
        function () {
          el('pdf-progress-bar').style.width = '100%';
          setTimeout(function () { el('pdf-progress').hidden = true; el('pdf-progress-bar').style.width = '0'; }, 1200);
          renderTudo();
          toast('PDFs processados.');
        },
        function (m) { logar('log-pdf', m); });
      e.target.value = '';
    }
    el('in-pdfs').addEventListener('change', importarPdfs);
    el('in-pasta').addEventListener('change', importarPdfs);

    el('btn-backup').addEventListener('click', function () {
      I.exportarBackup();
      logar('log-backup', 'Backup gerado em ' + new Date().toLocaleString('pt-BR') + '.');
    });
    el('in-json').addEventListener('change', function (e) {
      var arq = e.target.files[0];
      if (!arq) return;
      I.importarBackup(arq, function () { renderTudo(); toast('Backup restaurado.'); },
        function (m) { logar('log-backup', m); });
      e.target.value = '';
    });
    el('btn-exportar-xlsx').addEventListener('click', function () {
      if (!I.exportarXLSX(S.propostas)) toast('Nada para exportar.');
    });
    el('in-json-extrator').addEventListener('change', function (e) {
      var arq = e.target.files[0];
      if (!arq) return;
      el('log-extrator').innerHTML = '';
      I.importarJsonExtrator(arq, function () { renderTudo(); toast('Propostas atualizadas.'); },
        function (m) { logar('log-extrator', m); });
      e.target.value = '';
    });
    el('btn-limpar').addEventListener('click', function () {
      if (confirm('Apagar todas as propostas e atividades deste dispositivo?')) {
        S.limpar(); renderTudo(); toast('Base limpa.');
      }
    });
  }

  function ligarConfig() {
    el('btn-salvar-config').addEventListener('click', function () {
      S.config.metaPropostas = parseInt(el('cfg-meta-propostas').value, 10) || 0;
      S.config.metaValor = S.numero(el('cfg-meta-valor').value);
      el('cfg-meta-valor').value = S.valorCampo(S.config.metaValor);
      S.config.diasFollowup = parseInt(el('cfg-dias-followup').value, 10) || 15;
      S.salvar();
      toast('Ajustes salvos.');
      renderPainel();
    });
    el('btn-add-vendedor').addEventListener('click', function () {
      var nome = el('novo-vendedor').value.trim();
      if (!nome) return;
      if (S.vendedores.indexOf(nome) === -1) S.vendedores.push(nome);
      S.salvar();
      el('novo-vendedor').value = '';
      renderConfig(); preencherSelects();
    });
  }

  /* ---------------- inicialização ---------------- */

  function iniciar() {
    if (!S.localOk) {
      el('storage-hint').textContent = 'Este navegador bloqueia o armazenamento local: exporte o backup antes de fechar.';
    }
    ligarEventos();
    preencherSelects();
    mostrarView('painel');
    if (!S.propostas.length) {
      setTimeout(function () { toast('Comece importando sua planilha em Importar.'); }, 700);
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
  else iniciar();
})();
