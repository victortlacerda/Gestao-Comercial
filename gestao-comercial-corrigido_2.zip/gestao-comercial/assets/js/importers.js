/* ===========================================================
   importers.js — planilha, PDFs, backup e exportações
   =========================================================== */
(function () {
  'use strict';

  var S = window.Store;

  /* ---------------- Planilha (.xlsm / .xlsx) ---------------- */

  var MAPA_COLUNAS = {
    'contrato': 'contrato',
    'nome do cliente': 'cliente',
    'cliente': 'cliente',
    'cnpj': 'cnpj',
    'responsavel': 'contato',
    'nome contato': 'contato',
    'telefone': 'telefone',
    'email': 'email',
    'e-mail': 'email',
    'cidade': 'cidade',
    'estado': 'estado',
    'uf': 'estado',
    'servico': 'servico',
    'tipo de servico': 'servico',
    'descricao': 'descricao',
    'valor total estimado': 'valor',
    'valor': 'valor',
    'semana consulta': 'semanaConsulta',
    'proposta enviada': '_enviada',
    'mes da proposta enviada': '_mesEnviada',
    'status': '_status',
    'mes da proposta fechada': '_mesFechada',
    'probabilidade': 'classificacao',
    'temperatura': '_temperatura',
    'classificacao': 'tipoCliente',
    'obra': 'obra',
    'obra (pdf)': 'obra',
    'vendedor': 'vendedor',
    'codigo pdf': 'contrato',
    'ref. pasta': '_refPasta'
  };

  function normalizarStatus(bruto, enviada) {
    var t = S.normalizar(bruto);
    if (t.indexOf('fechad') > -1) return 'Fechada';
    if (t.indexOf('perdid') > -1) return 'Perdida';
    if (t.indexOf('negocia') > -1) return 'Em negociação';
    if (t.indexOf('aguardando') > -1) return 'Aguardando retorno';
    if (t.indexOf('nao enviada') > -1) return 'Nova';
    var e = S.normalizar(enviada);
    if (e === 'sim') return 'Enviada';
    return 'Nova';
  }

  function normalizarClassificacao(bruto) {
    var t = S.normalizar(bruto);
    if (t.indexOf('boa') > -1 || t.indexOf('bom') > -1) return 'Boa';
    if (t.indexOf('ruim') > -1) return 'Ruim';
    if (t.indexOf('regular') > -1) return 'Regular';
    return 'Regular';
  }

  /** "FEV - SEM 02" -> segunda-feira dessa semana no calendário do ano. */
  function dataDaSemana(txt, anoRef) {
    return S.dataDaSemana(txt, anoRef);
  }

  /** "QUENTE"/"morno"/"Frio" -> valor do sistema. Vazio quando não reconhece. */
  function normalizarTemperatura(bruto) {
    var t = S.normalizar(bruto);
    if (!t) return '';
    if (t.indexOf('quent') > -1) return 'Quente';
    if (t.indexOf('morn') > -1) return 'Morno';
    if (t.indexOf('fri') > -1) return 'Frio';
    return '';
  }

  /**
   * Data de fechamento a partir de "MAI - SEM 04".
   * Mês de fechamento anterior ao da proposta = fechou no ano seguinte
   * (proposta em DEZ, fechada em JAN). E o fechamento nunca fica antes da
   * emissão: quando caem na mesma semana, vale o dia da proposta.
   */
  function dataDoFechamento(rotulo, p, anoRef) {
    var s = S.lerSemana(rotulo);
    if (!s || !s.mes) return p.dataProposta || '';
    var mesProposta = p.dataProposta ? +p.dataProposta.slice(5, 7) : 0;
    var ano = (mesProposta && s.mes < mesProposta) ? anoRef + 1 : anoRef;
    var iso = S.segundaDaSemana(s.mes, s.semana, ano);
    if (!iso) return p.dataProposta || '';
    return (p.dataProposta && iso < p.dataProposta) ? p.dataProposta : iso;
  }

  /** Converte as linhas da aba PROPOSTAS em propostas do app. */
  function mapearLinhas(linhas) {
    var itens = [], ignoradas = 0;
    linhas.forEach(function (linha) {
      var item = {};
      Object.keys(linha).forEach(function (col) {
        var destino = MAPA_COLUNAS[S.normalizar(col)];
        if (destino) item[destino] = linha[col];
      });

      if (!String(item.cliente || '').trim() && !String(item.contrato || '').trim()) { ignoradas++; return; }

      var p = {
        contrato: String(item.contrato || '').trim(),
        cliente: String(item.cliente || '').trim().toUpperCase(),
        cnpj: String(item.cnpj || '').trim(),
        contato: String(item.contato || '').trim(),
        telefone: String(item.telefone || '').trim(),
        email: String(item.email || '').trim(),
        cidade: String(item.cidade || '').trim(),
        estado: String(item.estado || '').trim().toUpperCase().slice(0, 2),
        servico: String(item.servico || '').trim().toUpperCase(),
        descricao: String(item.descricao || '').trim(),
        obra: String(item.obra || '').trim(),
        valor: S.numero(item.valor),
        semanaConsulta: String(item.semanaConsulta || '').trim(),
        status: normalizarStatus(item._status, item._enviada),
        classificacao: normalizarClassificacao(item.classificacao),
        temperatura: normalizarTemperatura(item._temperatura),
        tipoCliente: S.normalizar(item.tipoCliente).indexOf('antigo') > -1 ? 'ANTIGO' : 'NOVO',
        vendedor: String(item.vendedor || '').trim()
      };
      p.dataProposta = S.dataDoContrato(p.contrato) || dataDaSemana(item._mesEnviada || item.semanaConsulta) || '';
      var anoRef = p.dataProposta ? +p.dataProposta.slice(0, 4) : new Date().getFullYear();
      if (p.status === 'Fechada') p.dataFechamento = dataDoFechamento(item._mesFechada, p, anoRef);
      itens.push(p);
    });
    return { itens: itens, ignoradas: ignoradas };
  }

  function lerPlanilha(arquivo, aoTerminar, aoLogar) {
    var leitor = new FileReader();
    leitor.onload = function (ev) {
      try {
        var wb = XLSX.read(new Uint8Array(ev.target.result), { type: 'array' });
        var nomeAba = wb.SheetNames.find(function (n) { return S.normalizar(n).indexOf('proposta') > -1 && S.normalizar(n).indexOf('fechada') === -1; }) || wb.SheetNames[0];
        aoLogar('Lendo a aba "' + nomeAba + '".');
        var linhas = XLSX.utils.sheet_to_json(wb.Sheets[nomeAba], { defval: '', raw: true });
        var convertido = mapearLinhas(linhas);
        var itens = convertido.itens;
        var ignoradas = convertido.ignoradas;

        var r = S.mesclar(itens, { preservarEdicoes: false });
        aoLogar(itens.length + ' linhas convertidas — ' + r.novos + ' novas, ' + r.atualizados + ' atualizadas.');
        if (ignoradas) aoLogar(ignoradas + ' linhas vazias ignoradas.');
        if (r.conflitos && r.conflitos.length) {
          aoLogar('⚠ ' + r.conflitos.length + ' contrato(s) repetido(s) com clientes diferentes. ' +
                  'Cada proposta foi mantida separada — confira a numeração na planilha:');
          r.conflitos.slice(0, 20).forEach(function (c) {
            aoLogar('· ' + c.contrato + ' → ' + c.clientes.join('  |  '));
          });
        }
        aoTerminar(r);
      } catch (erro) {
        aoLogar('Não foi possível ler a planilha: ' + erro.message);
      }
    };
    leitor.onerror = function () { aoLogar('Falha ao abrir o arquivo.'); };
    leitor.readAsArrayBuffer(arquivo);
  }

  /* ---------------- PDFs ---------------- */

  var PADROES = {
    contrato: /(?:Proposta\s*n?[ºo°.]?|REFER[ÊE]NCIA)\s*:?\s*(\d{6}\s*-\s*\d{3})/i,
    cnpj: /CNPJ\s*:?\s*(\d{2}\s*\.?\s*\d{3}\s*\.?\s*\d{3}\s*\/?\s*\d{4}\s*-?\s*\d{2})/i,
    contato: /A\s*\/\s*C\s*:?\s*([^\n]{2,60})/i,
    telefone: /(?:Tel|Telefone|Fone)\s*\.?\s*:\s*([()\d\s\-+.]{8,25})/i,
    email: /E\s*-?\s*mail\s*:?\s*([\w.\-+]+@[\w.\-]+\.\w{2,})/i,
    obra: /Obra\s*:?\s*([^\n]{2,80})/i,
    cliente: /(?:Cliente|Raz[ãa]o Social)\s*:?\s*([^\n]{2,70})/i,
    valor: /Valor\s+total\s*:\s*R?\$?\s*([\d.,]{4,})/i,
    valorAlt: /(?:valor\s+(?:total|global|da\s+proposta))[^\d\n]{0,20}(\d[\d.,]{3,})/i
  };

  function extrairDoTexto(texto) {
    var achado = {};
    Object.keys(PADROES).forEach(function (chave) {
      var m = PADROES[chave].exec(texto);
      if (!m) return;
      var v = m[1].replace(/\s+/g, ' ').trim();
      if (chave === 'contrato' || chave === 'cnpj') v = v.replace(/\s/g, '');
      if (chave === 'valor' || chave === 'valorAlt') v = S.numero(v);
      achado[chave] = v;
    });

    if (!achado.valor && achado.valorAlt) achado.valor = achado.valorAlt;
    delete achado.valorAlt;

    // "Obra: Patolamento de guindaste – Concórdia/SC" -> cidade e UF
    if (achado.obra) {
      var loc = /([A-Za-zÀ-ÿ' .]{3,40})\s*\/\s*([A-Z]{2})\s*\.?\s*$/.exec(achado.obra);
      if (loc) {
        achado.cidade = loc[1].replace(/^[\s–-]+/, '').trim().toUpperCase();
        achado.estado = loc[2].toUpperCase();
      }
    }
    return achado;
  }

  /** "Proposta 145 - CLIENTE - CIDADE - SERVIÇO" */
  function extrairDaPasta(nome) {
    var partes = String(nome || '').split(/\s*-\s*/).map(function (s) { return s.trim(); });
    return {
      cliente: partes[1] ? partes[1].toUpperCase() : '',
      cidade: partes[2] || '',
      servico: partes[3] ? partes[3].toUpperCase() : ''
    };
  }

  /** Remonta o texto de uma página respeitando linhas e espaços reais. */
  function montarTexto(items) {
    var linhas = [], atual = null, ultimoY = null, fimX = null;
    items.forEach(function (it) {
      if (!it.str) return;
      var x = it.transform ? it.transform[4] : 0;
      var y = it.transform ? Math.round(it.transform[5]) : 0;
      if (ultimoY === null || Math.abs(y - ultimoY) > 2) {
        atual = []; linhas.push(atual); ultimoY = y; fimX = null;
      }
      // só insere espaço quando há um vão real entre os trechos
      if (fimX !== null && x - fimX > 1.2 && !/\s$/.test(atual[atual.length - 1] || '')) atual.push(' ');
      atual.push(it.str);
      fimX = x + (it.width || 0);
    });
    return linhas.map(function (l) {
      return l.join('').replace(/[ \t]+/g, ' ').trim();
    }).filter(Boolean).join('\n');
  }

  function textoDoPdf(arquivo) {
    return arquivo.arrayBuffer().then(function (buffer) {
      return pdfjsLib.getDocument({ data: new Uint8Array(buffer) }).promise;
    }).then(function (doc) {
      var paginas = [];
      for (var i = 1; i <= Math.min(doc.numPages, 10); i++) paginas.push(i);
      return Promise.all(paginas.map(function (n) {
        return doc.getPage(n).then(function (pg) { return pg.getTextContent(); })
          .then(function (c) { return montarTexto(c.items); });
      })).then(function (textos) { return textos.join('\n'); });
    });
  }

  /**
   * Lê o nome do arquivo no padrão
   * "Proposta - DDMMAA - Número - CLIENTE - SERVIÇO [- Rev.01]".
   */
  function analisarNomeArquivo(nomeArquivo) {
    var nome = String(nomeArquivo || '').replace(/\.pdf$/i, '').replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
    var m = /^proposta\s*[-–]?\s*(\d{2})\s*(\d{2})\s*(\d{2})\s*[-–]\s*(\d{1,4})\s*[-–]\s*(.*)$/i.exec(nome);
    if (!m) return null;

    var resto = m[5] || '';
    var revisao = 0;
    var rev = /[-–]?\s*rev\.?\s*(\d{1,2})\s*$/i.exec(resto);
    if (rev) { revisao = parseInt(rev[1], 10) || 0; resto = resto.slice(0, rev.index); }

    var partes = resto.split(/\s*[-–]\s*/).map(function (s) { return s.trim(); }).filter(Boolean);
    var servico = partes.length > 1 ? partes[partes.length - 1] : '';
    var cliente = partes.length > 1 ? partes.slice(0, -1).join(' - ') : (partes[0] || '');

    return {
      contrato: m[1] + m[2] + m[3] + '-' + String(m[4]).padStart(3, '0'),
      dataProposta: (2000 + +m[3]) + '-' + m[2] + '-' + m[1],
      cliente: cliente.toUpperCase(),
      servico: servico.toUpperCase(),
      revisao: revisao
    };
  }

  /**
   * Escolhe um PDF por proposta: o da revisão mais recente.
   * Arquivos fora do padrão (ART, contrato, memorial) ficam de fora,
   * a não ser que a pasta não tenha nenhum PDF no padrão.
   */
  function selecionarPdfs(lista, aoLogar) {
    var porProposta = {};
    var semPadrao = {};

    lista.forEach(function (arquivo) {
      var caminho = arquivo.webkitRelativePath || '';
      var pastas = caminho.split('/');
      var pasta = pastas.length > 1 ? pastas.slice(0, -1).join('/') : '';
      var info = analisarNomeArquivo(arquivo.name);

      if (info) {
        var atual = porProposta[info.contrato];
        if (!atual) {
          porProposta[info.contrato] = { arquivo: arquivo, info: info, pasta: pasta, versoes: 1 };
        } else if (info.revisao > atual.info.revisao) {
          aoLogar('· revisão anterior ignorada: ' + atual.arquivo.name);
          porProposta[info.contrato] = { arquivo: arquivo, info: info, pasta: pasta, versoes: atual.versoes + 1 };
        } else {
          atual.versoes++;
          aoLogar('· revisão anterior ignorada: ' + arquivo.name);
        }
      } else {
        if (!semPadrao[pasta]) semPadrao[pasta] = [];
        semPadrao[pasta].push(arquivo);
      }
    });

    var escolhidos = Object.keys(porProposta).map(function (k) { return porProposta[k]; });
    var pastasComPadrao = {};
    escolhidos.forEach(function (e) { pastasComPadrao[e.pasta] = true; });

    Object.keys(semPadrao).forEach(function (pasta) {
      if (pastasComPadrao[pasta]) {
        aoLogar('· ' + semPadrao[pasta].length + ' anexo(s) ignorado(s) em "' + (pasta.split('/').pop() || 'raiz') + '"');
        return;
      }
      // pasta sem nenhum arquivo no padrão: lê o primeiro PDF para não perder a proposta
      var primeiro = semPadrao[pasta].slice().sort(function (a, b) { return a.name.localeCompare(b.name); })[0];
      aoLogar('· fora do padrão, lendo assim mesmo: ' + primeiro.name);
      escolhidos.push({ arquivo: primeiro, info: null, pasta: pasta, versoes: 1 });
    });

    return escolhidos;
  }

  function processarPdfs(arquivos, aoProgredir, aoTerminar, aoLogar) {
    var pdfs = Array.prototype.slice.call(arquivos).filter(function (f) {
      return /\.pdf$/i.test(f.name);
    });
    if (!pdfs.length) { aoLogar('Nenhum PDF encontrado na seleção.'); aoTerminar(null); return; }

    var selecao = selecionarPdfs(pdfs, aoLogar);
    aoLogar(pdfs.length + ' PDFs na seleção → ' + selecao.length + ' proposta(s) a ler.');

    if (window.pdfjsLib && pdfjsLib.GlobalWorkerOptions) {
      pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    }

    var itens = [], indice = 0, falhas = 0;

    function proximo() {
      if (indice >= selecao.length) {
        var r = S.mesclar(itens, { preservarEdicoes: true });
        aoLogar('Concluído: ' + r.novos + ' propostas novas e ' + r.atualizados + ' atualizadas.');
        if (falhas) aoLogar(falhas + ' PDFs não puderam ser lidos (provavelmente digitalizados, sem texto).');
        aoTerminar(r);
        return;
      }
      var escolhido = selecao[indice];
      var arquivo = escolhido.arquivo;
      var nomePasta = escolhido.pasta ? escolhido.pasta.split('/').pop() : '';

      aoProgredir(indice / selecao.length, arquivo.name);

      textoDoPdf(arquivo).then(function (texto) {
        var doPdf = extrairDoTexto(texto);
        var doNome = escolhido.info || {};
        var daPasta = nomePasta ? extrairDaPasta(nomePasta) : {};
        var p = {
          contrato: doNome.contrato || doPdf.contrato || '',
          cliente: doNome.cliente || daPasta.cliente || doPdf.cliente || '',
          cidade: daPasta.cidade || doPdf.cidade || '',
          estado: doPdf.estado || '',
          servico: doNome.servico || daPasta.servico || '',
          cnpj: doPdf.cnpj || '',
          contato: doPdf.contato || '',
          telefone: doPdf.telefone || '',
          email: doPdf.email || '',
          obra: doPdf.obra || '',
          valor: doPdf.valor || 0,
          revisao: doNome.revisao || 0,
          arquivo: arquivo.name
        };
        if (doNome.dataProposta) p.dataProposta = doNome.dataProposta;
        if (!p.contrato && !p.cliente) { falhas++; aoLogar('Sem dados reconhecidos: ' + arquivo.name); }
        else {
          itens.push(p);
          aoLogar('✓ ' + (p.contrato || '—') + '  ' + (p.cliente || arquivo.name) +
            (p.revisao ? '  (Rev.' + String(p.revisao).padStart(2, '0') + ')' : ''));
        }
      }).catch(function (e) {
        falhas++;
        aoLogar('✗ ' + arquivo.name + ' (' + e.message + ')');
      }).then(function () {
        indice++;
        proximo();
      });
    }
    proximo();
  }

  /* ---------------- Backup e exportações ---------------- */

  function baixar(nome, conteudo, tipo) {
    var blob = conteudo instanceof Blob ? conteudo : new Blob([conteudo], { type: tipo || 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = nome;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  }

  function carimbo() {
    var d = new Date();
    return d.toISOString().slice(0, 10).replace(/-/g, '') + '_' + String(d.getHours()).padStart(2, '0') + String(d.getMinutes()).padStart(2, '0');
  }

  function exportarBackup() {
    baixar('backup_gestao_comercial_' + carimbo() + '.json', JSON.stringify(S.estado, null, 2), 'application/json');
  }

  function importarBackup(arquivo, aoTerminar, aoLogar) {
    var leitor = new FileReader();
    leitor.onload = function (ev) {
      try {
        var dados = JSON.parse(ev.target.result);
        if (!dados.propostas) throw new Error('arquivo sem lista de propostas');
        S.substituirTudo(dados);
        aoLogar('Backup restaurado: ' + dados.propostas.length + ' propostas.');
        aoTerminar();
      } catch (e) { aoLogar('Arquivo inválido: ' + e.message); }
    };
    leitor.readAsText(arquivo);
  }

  function importarJsonExtrator(arquivo, aoTerminar, aoLogar) {
    var leitor = new FileReader();
    leitor.onload = function (ev) {
      try {
        var lista = JSON.parse(ev.target.result);
        if (!Array.isArray(lista)) throw new Error('esperava uma lista de propostas');
        var itens = lista.map(function (x) {
          return {
            contrato: String(x.contrato || x['Código PDF'] || x.codigo || '').trim(),
            cliente: String(x.cliente || x.Cliente || '').trim().toUpperCase(),
            cnpj: String(x.cnpj || x.CNPJ || '').trim(),
            contato: String(x.contato || x['Nome Contato'] || '').trim(),
            telefone: String(x.telefone || x.Telefone || '').trim(),
            email: String(x.email || x.Email || '').trim(),
            cidade: String(x.cidade || x.Cidade || '').trim(),
            estado: String(x.estado || x.Estado || '').trim().toUpperCase().slice(0, 2),
            servico: String(x.servico || x['Tipo de Serviço'] || '').trim().toUpperCase(),
            obra: String(x.obra || x['Obra (PDF)'] || '').trim(),
            valor: S.numero(x.valor || x.Valor || 0)
          };
        }).filter(function (p) { return p.contrato || p.cliente; });
        var r = S.mesclar(itens, { preservarEdicoes: true });
        aoLogar(r.novos + ' novas e ' + r.atualizados + ' atualizadas a partir do extrator.');
        aoTerminar(r);
      } catch (e) { aoLogar('Arquivo inválido: ' + e.message); }
    };
    leitor.readAsText(arquivo);
  }

  function linhasExportacao(lista) {
    return lista.map(function (p) {
      return {
        'Contrato': p.contrato,
        'Cliente': p.cliente,
        'CNPJ': p.cnpj,
        'Contato': p.contato,
        'Telefone': p.telefone,
        'Email': p.email,
        'Cidade': p.cidade,
        'UF': p.estado,
        'Serviço': p.servico,
        'Descrição': p.descricao,
        'Obra': p.obra,
        'Valor': S.numero(p.valor),
        'Revisão': p.revisao || 0,
        'Status': p.status,
        'Classificação': p.classificacao,
        'Temperatura': p.temperatura || '',
        'Tipo de cliente': p.tipoCliente,
        'Vendedor': p.vendedor,
        'Data da proposta': p.dataProposta,
        'Entrou na etapa em': S.entradaNaEtapa(p) || '',
        'Dias na etapa': S.diasNaEtapa(p),
        'Último contato': S.ultimoContato(p) || '',
        'Dias sem contato': S.diasSemContato(p),
        'Próximo contato': p.proximoContato || '',
        'Motivo da perda': p.motivoPerda || '',
        'Ligações': S.contarAtividades(p, 'Ligação'),
        'Reuniões': S.contarAtividades(p, 'Reunião'),
        'Observações': p.observacoes || ''
      };
    });
  }

  function exportarCSV(lista) {
    var linhas = linhasExportacao(lista);
    if (!linhas.length) return false;
    var cab = Object.keys(linhas[0]);
    var corpo = linhas.map(function (l) {
      return cab.map(function (c) {
        var v = l[c] == null ? '' : String(l[c]);
        return '"' + v.replace(/"/g, '""') + '"';
      }).join(';');
    });
    baixar('propostas_' + carimbo() + '.csv', '\ufeff' + cab.join(';') + '\n' + corpo.join('\n'), 'text/csv;charset=utf-8');
    return true;
  }

  function exportarXLSX(lista) {
    var linhas = linhasExportacao(lista);
    if (!linhas.length) return false;
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(linhas), 'PROPOSTAS');

    var atividades = [];
    lista.forEach(function (p) {
      (p.atividades || []).forEach(function (a) {
        atividades.push({
          'Contrato': p.contrato, 'Cliente': p.cliente, 'Data': a.data, 'Hora': a.hora || '',
          'Tipo': a.tipo, 'Responsável': a.responsavel, 'Observação': a.obs
        });
      });
    });
    if (atividades.length) XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(atividades), 'ATIVIDADES');
    XLSX.writeFile(wb, 'gestao_comercial_' + carimbo() + '.xlsx');
    return true;
  }

  /* ---------------- planilha de obras fechadas ---------------- */

  /** Ajusta largura das colunas, filtro do cabeçalho e formato de moeda/porcentagem. */
  function ajustar(ws, linhas, formatos) {
    if (!linhas.length) return ws;
    var cab = Object.keys(linhas[0]);
    ws['!cols'] = cab.map(function (c) {
      var maior = String(c).length;
      linhas.forEach(function (l) {
        var t = l[c] == null ? '' : String(l[c]);
        if (t.length > maior) maior = t.length;
      });
      return { wch: Math.min(Math.max(maior + 2, 7), 44) };
    });
    ws['!autofilter'] = {
      ref: XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: linhas.length, c: cab.length - 1 } })
    };
    formatos = formatos || {};
    Object.keys(formatos).forEach(function (fmt) {
      formatos[fmt].forEach(function (nomeCol) {
        var ci = cab.indexOf(nomeCol);
        if (ci < 0) return;
        for (var r = 1; r <= linhas.length; r++) {
          var cel = ws[XLSX.utils.encode_cell({ r: r, c: ci })];
          if (cel && cel.t === 'n') cel.z = fmt === 'moeda' ? 'R$ #,##0.00' : '0.0%';
        }
      });
    });
    return ws;
  }

  /** Serviços da proposta separados entre os da lista oficial e os avulsos. */
  function servicosDaProposta(p) {
    var achados = S.servicos(p) || [];
    var oficiais = achados.filter(function (s) { return S.SERVICOS.indexOf(s) > -1; });
    var outros = achados.filter(function (s) { return S.SERVICOS.indexOf(s) === -1; });
    return { todos: achados, oficiais: oficiais, outros: outros };
  }

  function mesAno(iso) {
    if (!iso || iso.length < 7) return '';
    return iso.slice(5, 7) + '/' + iso.slice(0, 4);
  }

  /** Uma linha por obra fechada, com uma coluna para cada serviço. */
  function linhasObrasFechadas(lista) {
    return lista.map(function (p) {
      var sv = servicosDaProposta(p);
      var fech = S.dataDeFechamento(p);
      var linha = {
        'Contrato': p.contrato || '',
        'Cliente': p.cliente || '',
        'Obra': p.obra || '',
        'Cidade': p.cidade || '',
        'UF': p.estado || '',
        'Valor (R$)': S.numero(p.valor),
        'Qtd. de serviços': sv.todos.length,
        'Serviços': sv.todos.join(' + ') || (p.servico || '')
      };
      S.SERVICOS.forEach(function (s) { linha[s] = sv.oficiais.indexOf(s) > -1 ? 1 : 0; });
      linha['Outros serviços'] = sv.outros.join(' + ');
      linha['Data da proposta'] = S.dataBR(p.dataProposta);
      linha['Data de fechamento'] = fech ? S.dataBR(fech) : '';
      linha['Semana de fechamento'] = S.rotuloSemana(fech);
      linha['Mês de fechamento'] = mesAno(fech);
      linha['Dias até fechar'] = S.diasParaFechar(p);
      linha['Vendedor'] = p.vendedor || '';
      linha['Classificação'] = p.classificacao || '';
      linha['Temperatura'] = p.temperatura || '';
      linha['Tipo de cliente'] = p.tipoCliente || '';
      linha['CNPJ'] = p.cnpj || '';
      linha['Contato'] = p.contato || '';
      linha['Telefone'] = p.telefone || '';
      linha['E-mail'] = p.email || '';
      linha['Descrição'] = p.descricao || '';
      linha['Revisão'] = p.revisao || 0;
      linha['Ligações'] = S.contarAtividades(p, 'Ligação');
      linha['Reuniões'] = S.contarAtividades(p, 'Reunião');
      linha['Total de contatos'] = (p.atividades || []).length;
      linha['Último contato'] = S.ultimoContato(p) ? S.dataBR(S.ultimoContato(p)) : '';
      linha['Observações'] = p.observacoes || '';
      return linha;
    });
  }

  /** Uma linha por obra × serviço — pronto para tabela dinâmica. */
  function linhasPorServico(lista) {
    var saida = [];
    lista.forEach(function (p) {
      var sv = servicosDaProposta(p);
      var itens = sv.todos.length ? sv.todos : ['(sem serviço informado)'];
      var valor = S.numero(p.valor);
      var fech = S.dataDeFechamento(p);
      itens.forEach(function (s) {
        saida.push({
          'Serviço': s,
          'Contrato': p.contrato || '',
          'Cliente': p.cliente || '',
          'Obra': p.obra || '',
          'Cidade': p.cidade || '',
          'UF': p.estado || '',
          'Quantidade': 1,
          'Valor da obra (R$)': valor,
          'Valor rateado (R$)': itens.length ? valor / itens.length : valor,
          'Serviços na mesma obra': itens.length,
          'Data de fechamento': fech ? S.dataBR(fech) : '',
          'Semana de fechamento': S.rotuloSemana(fech),
          'Mês de fechamento': mesAno(fech),
          'Vendedor': p.vendedor || ''
        });
      });
    });
    return saida.sort(function (a, b) {
      return String(a['Serviço']).localeCompare(String(b['Serviço'])) ||
        String(a['Cliente']).localeCompare(String(b['Cliente']));
    });
  }

  function resumoPorServico(lista) {
    var mapa = {};
    var totalObras = lista.length || 1;
    lista.forEach(function (p) {
      var sv = servicosDaProposta(p);
      var itens = sv.todos.length ? sv.todos : ['(sem serviço informado)'];
      var valor = S.numero(p.valor);
      itens.forEach(function (s) {
        if (!mapa[s]) mapa[s] = { s: s, obras: 0, valor: 0, rateado: 0 };
        mapa[s].obras++;
        mapa[s].valor += valor;
        mapa[s].rateado += valor / itens.length;
      });
    });
    return Object.keys(mapa).map(function (k) { return mapa[k]; })
      .sort(function (a, b) { return b.obras - a.obras || b.rateado - a.rateado; })
      .map(function (x) {
        return {
          'Serviço': x.s,
          'Obras fechadas': x.obras,
          '% das obras': x.obras / totalObras,
          'Valor das obras (R$)': x.valor,
          'Valor rateado (R$)': x.rateado
        };
      });
  }

  function resumoPorChave(lista, rotulo, fn) {
    var grupos = S.agruparPor(lista, fn);
    return grupos.map(function (g) {
      var servicos = {};
      g.itens.forEach(function (p) {
        (S.servicos(p) || []).forEach(function (s) { servicos[s] = (servicos[s] || 0) + 1; });
      });
      var lin = {};
      lin[rotulo] = g.chave;
      lin['Obras fechadas'] = g.qtd;
      lin['Valor total (R$)'] = g.valor;
      lin['Ticket médio (R$)'] = g.qtd ? g.valor / g.qtd : 0;
      lin['Serviços'] = Object.keys(servicos).map(function (s) {
        return s + (servicos[s] > 1 ? ' (' + servicos[s] + ')' : '');
      }).join(', ');
      return lin;
    });
  }

  /**
   * Gera a planilha de obras fechadas.
   * lista  — propostas já filtradas (só as Fechadas entram)
   * ctx    — { escopo: 'texto do período', vendedor: 'nome ou vazio' }
   */
  function exportarObrasFechadas(lista, ctx) {
    ctx = ctx || {};
    var fechadas = (lista || []).filter(function (p) { return p.status === 'Fechada'; })
      .sort(function (a, b) {
        return String(S.dataDeFechamento(b)).localeCompare(String(S.dataDeFechamento(a)));
      });
    if (!fechadas.length) return 0;

    var obras = linhasObrasFechadas(fechadas);
    var porServico = linhasPorServico(fechadas);
    var resumoServ = resumoPorServico(fechadas);
    var porCidade = resumoPorChave(fechadas, 'Cidade', function (p) {
      return (p.cidade || '—') + (p.estado ? '/' + p.estado : '');
    });
    var porCliente = resumoPorChave(fechadas, 'Cliente', 'cliente');
    var porVendedor = resumoPorChave(fechadas, 'Vendedor', function (p) { return p.vendedor || 'Sem vendedor'; });

    var total = fechadas.reduce(function (t, p) { return t + S.numero(p.valor); }, 0);
    var totalServicos = porServico.length;

    var cabecalho = [
      ['OBRAS FECHADAS — SAMMOUR ENGENHARIA'],
      [],
      ['Período', ctx.escopo || 'todo o período'],
      ['Vendedor', ctx.vendedor || 'toda a equipe'],
      ['Emitido em', S.dataBR(S.hojeISO())],
      [],
      ['Obras fechadas', fechadas.length],
      ['Valor total (R$)', total],
      ['Ticket médio (R$)', fechadas.length ? total / fechadas.length : 0],
      ['Serviços contratados (soma)', totalServicos],
      ['Tipos de serviço diferentes', resumoServ.length],
      [],
      ['Serviço', 'Obras', '% das obras', 'Valor das obras (R$)', 'Valor rateado (R$)']
    ];
    resumoServ.forEach(function (r) {
      cabecalho.push([r['Serviço'], r['Obras fechadas'], r['% das obras'], r['Valor das obras (R$)'], r['Valor rateado (R$)']]);
    });
    cabecalho.push([]);
    cabecalho.push(['Como ler: uma obra pode ter mais de um serviço. "Valor das obras" soma o valor cheio de toda obra que']);
    cabecalho.push(['inclui aquele serviço; "Valor rateado" divide o valor da obra entre os serviços dela, então a soma da']);
    cabecalho.push(['coluna rateada bate com o valor total acima.']);

    var wsResumo = XLSX.utils.aoa_to_sheet(cabecalho);
    wsResumo['!cols'] = [{ wch: 34 }, { wch: 14 }, { wch: 14 }, { wch: 22 }, { wch: 20 }];
    ['B8', 'B9'].forEach(function (ref) { if (wsResumo[ref]) wsResumo[ref].z = 'R$ #,##0.00'; });
    for (var i = 0; i < resumoServ.length; i++) {
      var r0 = 14 + i;
      if (wsResumo['C' + r0]) wsResumo['C' + r0].z = '0.0%';
      if (wsResumo['D' + r0]) wsResumo['D' + r0].z = 'R$ #,##0.00';
      if (wsResumo['E' + r0]) wsResumo['E' + r0].z = 'R$ #,##0.00';
    }

    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, wsResumo, 'RESUMO');
    XLSX.utils.book_append_sheet(wb, ajustar(XLSX.utils.json_to_sheet(obras), obras,
      { moeda: ['Valor (R$)'] }), 'OBRAS FECHADAS');
    XLSX.utils.book_append_sheet(wb, ajustar(XLSX.utils.json_to_sheet(porServico), porServico,
      { moeda: ['Valor da obra (R$)', 'Valor rateado (R$)'] }), 'POR SERVIÇO');
    XLSX.utils.book_append_sheet(wb, ajustar(XLSX.utils.json_to_sheet(resumoServ), resumoServ,
      { moeda: ['Valor das obras (R$)', 'Valor rateado (R$)'], porcento: ['% das obras'] }), 'RESUMO SERVIÇOS');
    XLSX.utils.book_append_sheet(wb, ajustar(XLSX.utils.json_to_sheet(porCidade), porCidade,
      { moeda: ['Valor total (R$)', 'Ticket médio (R$)'] }), 'POR CIDADE');
    XLSX.utils.book_append_sheet(wb, ajustar(XLSX.utils.json_to_sheet(porCliente), porCliente,
      { moeda: ['Valor total (R$)', 'Ticket médio (R$)'] }), 'POR CLIENTE');
    XLSX.utils.book_append_sheet(wb, ajustar(XLSX.utils.json_to_sheet(porVendedor), porVendedor,
      { moeda: ['Valor total (R$)', 'Ticket médio (R$)'] }), 'POR VENDEDOR');

    XLSX.writeFile(wb, 'obras_fechadas_' + carimbo() + '.xlsx');
    return fechadas.length;
  }

  window.Importers = {
    lerPlanilha: lerPlanilha,
    mapearLinhas: mapearLinhas,
    processarPdfs: processarPdfs,
    exportarBackup: exportarBackup,
    importarBackup: importarBackup,
    importarJsonExtrator: importarJsonExtrator,
    exportarCSV: exportarCSV,
    exportarXLSX: exportarXLSX,
    exportarObrasFechadas: exportarObrasFechadas,
    extrairDoTexto: extrairDoTexto,
    montarTexto: montarTexto,
    extrairDaPasta: extrairDaPasta,
    analisarNomeArquivo: analisarNomeArquivo,
    selecionarPdfs: selecionarPdfs
  };
})();
