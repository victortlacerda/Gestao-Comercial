"""
Extrator de propostas — Sammour Engenharia
------------------------------------------
Percorre a pasta de propostas, lê o primeiro PDF de cada subpasta e gera
'propostas.json', que é carregado no app (tela Importar → "Carregar propostas.json").
Também gera um .xlsx opcional para conferência.

Uso:
    python extrator_propostas.py "C:/Caminho/Para/Propostas"
    python extrator_propostas.py                 # abre uma janela para escolher a pasta

Requisitos:
    pip install pymupdf pandas openpyxl
"""

import json
import re
import sys
from datetime import datetime
from pathlib import Path

import fitz  # PyMuPDF

PADROES = {
    "contrato": r"(?:Proposta\s*n?[ºo°.]?|REFER[ÊE]NCIA)\s*:?\s*(\d{6}\s*-\s*\d{3})",
    "cnpj": r"CNPJ\s*:?\s*(\d{2}\s*\.?\s*\d{3}\s*\.?\s*\d{3}\s*/?\s*\d{4}\s*-?\s*\d{2})",
    "contato": r"A\s*/\s*C\s*:?\s*(.+)",
    "telefone": r"(?:Tel|Telefone|Fone)\s*\.?\s*:\s*([()\d\s\-+.]{8,25})",
    "email": r"E\s*-?\s*mail\s*:?\s*([\w.\-+]+@[\w.\-]+\.\w{2,})",
    "obra": r"Obra\s*:?\s*(.+)",
    "valor": r"Valor\s+total\s*:\s*R?\$?\s*([\d.,]{4,})",
    "valor_alt": r"(?:valor\s+(?:total|global|da\s+proposta))[^\d\n]{0,20}(\d[\d.,]{3,})",
}

CAMPOS_VAZIOS = {k: "" for k in PADROES}
CAMPOS_VAZIOS.update({"cidade": "", "estado": ""})


def numero(texto: str) -> float:
    """Converte '1.234,56' ou '1234.56' em float."""
    limpo = re.sub(r"[^\d,.-]", "", str(texto))
    if not limpo:
        return 0.0
    if "," in limpo:
        limpo = limpo.replace(".", "").replace(",", ".")
    try:
        return float(limpo)
    except ValueError:
        return 0.0


def dados_da_pasta(nome_pasta: str) -> dict:
    """'Proposta 145 - CLIENTE - CIDADE - SERVIÇO'"""
    partes = [p.strip() for p in re.split(r"\s*-\s*", nome_pasta)]
    numero_proposta = 0
    achado = re.search(r"Proposta\s*(\d+)", partes[0], re.IGNORECASE) if partes else None
    if achado:
        numero_proposta = int(achado.group(1))
    return {
        "ordem": numero_proposta,
        "cliente": partes[1].upper() if len(partes) > 1 else "",
        "cidade": partes[2] if len(partes) > 2 else "",
        "servico": partes[3].upper() if len(partes) > 3 else "",
    }


def dados_do_pdf(caminho: Path) -> dict:
    achados = dict(CAMPOS_VAZIOS)
    try:
        texto = ""
        with fitz.open(caminho) as doc:
            for pagina in doc[: min(10, doc.page_count)]:
                texto += pagina.get_text()
    except Exception as erro:  # PDF corrompido, protegido ou digitalizado
        print(f"  ! não foi possível ler {caminho.name}: {erro}")
        return achados

    for chave, padrao in PADROES.items():
        m = re.search(padrao, texto, re.IGNORECASE)
        if not m:
            continue
        valor = " ".join(m.group(1).split())
        if chave in ("contrato", "cnpj"):
            valor = valor.replace(" ", "")
        achados[chave] = valor

    if not achados.get("valor"):
        achados["valor"] = achados.get("valor_alt", "")

    # "Obra: Patolamento de guindaste – Concórdia/SC" -> cidade e UF
    loc = re.search(r"([A-Za-zÀ-ÿ' .]{3,40})\s*/\s*([A-Z]{2})\s*\.?\s*$", achados.get("obra", ""))
    if loc:
        achados["cidade"] = loc.group(1).lstrip(" -–").strip().upper()
        achados["estado"] = loc.group(2).upper()
    return achados


PADRAO_ARQUIVO = re.compile(
    r"^proposta\s*-?\s*(\d{2})\s*(\d{2})\s*(\d{2})\s*-\s*(\d{1,4})\s*-\s*(.*)$",
    re.IGNORECASE,
)
PADRAO_REVISAO = re.compile(r"-?\s*rev\.?\s*(\d{1,2})\s*$", re.IGNORECASE)


def analisar_nome(nome_arquivo: str) -> dict | None:
    """'Proposta - DDMMAA - Número - CLIENTE - SERVIÇO [- Rev.01]'"""
    nome = " ".join(Path(nome_arquivo).stem.replace("_", " ").split())
    m = PADRAO_ARQUIVO.match(nome)
    if not m:
        return None

    resto = m.group(5) or ""
    revisao = 0
    rev = PADRAO_REVISAO.search(resto)
    if rev:
        revisao = int(rev.group(1))
        resto = resto[: rev.start()]

    partes = [p.strip() for p in resto.split("-") if p.strip()]
    servico = partes[-1].upper() if len(partes) > 1 else ""
    cliente = " - ".join(partes[:-1]).upper() if len(partes) > 1 else (partes[0].upper() if partes else "")

    return {
        "contrato": f"{m.group(1)}{m.group(2)}{m.group(3)}-{int(m.group(4)):03d}",
        "data": f"20{m.group(3)}-{m.group(2)}-{m.group(1)}",
        "cliente": cliente,
        "servico": servico,
        "revisao": revisao,
    }


def escolher_pdf(pasta: Path):
    """Devolve (arquivo, info, total_de_versoes): a revisão mais recente da proposta."""
    pdfs = sorted(pasta.glob("*.pdf"))
    candidatos = [(p, analisar_nome(p.name)) for p in pdfs]
    no_padrao = [(p, i) for p, i in candidatos if i]

    if no_padrao:
        arquivo, info = max(no_padrao, key=lambda x: x[1]["revisao"])
        return arquivo, info, len(no_padrao)
    if pdfs:  # pasta sem arquivo no padrão: usa o primeiro para não perder a proposta
        return pdfs[0], None, 1
    return None, None, 0


def processar(pasta_base: Path) -> list:
    subpastas = sorted(
        [d for d in pasta_base.iterdir() if d.is_dir()],
        key=lambda d: dados_da_pasta(d.name)["ordem"],
    )
    resultado = []
    total = len(subpastas)

    for i, pasta in enumerate(subpastas, start=1):
        da_pasta = dados_da_pasta(pasta.name)
        arquivo, do_nome, versoes = escolher_pdf(pasta)
        if arquivo is None:
            print(f"[{i}/{total}] {pasta.name}: nenhum PDF na pasta")
            continue

        do_pdf = dados_do_pdf(arquivo)
        do_nome = do_nome or {}

        proposta = {
            "contrato": do_nome.get("contrato") or do_pdf["contrato"],
            "cliente": do_nome.get("cliente") or da_pasta["cliente"],
            "cnpj": do_pdf["cnpj"],
            "contato": do_pdf["contato"],
            "telefone": do_pdf["telefone"],
            "email": do_pdf["email"],
            "cidade": da_pasta["cidade"] or do_pdf.get("cidade", ""),
            "estado": do_pdf.get("estado", ""),
            "servico": do_nome.get("servico") or da_pasta["servico"],
            "obra": do_pdf["obra"],
            "valor": numero(do_pdf["valor"]),
            "revisao": do_nome.get("revisao", 0),
            "arquivo": arquivo.name,
            "pasta": pasta.name,
        }
        if do_nome.get("data"):
            proposta["dataProposta"] = do_nome["data"]

        resultado.append(proposta)
        marca = f" (Rev.{proposta['revisao']:02d} de {versoes} versões)" if proposta["revisao"] else ""
        print(f"[{i}/{total}] {proposta['contrato'] or '------'}  {proposta['cliente']}{marca}")

    return resultado


def salvar(propostas: list, destino: Path) -> None:
    destino.write_text(json.dumps(propostas, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nArquivo gerado: {destino}")
    print("Abra o app → Importar → 'Carregar propostas.json'.")

    try:
        import pandas as pd

        xlsx = destino.with_suffix(".xlsx")
        pd.DataFrame(propostas).to_excel(xlsx, index=False)
        print(f"Planilha de conferência: {xlsx}")
    except ImportError:
        pass


def escolher_pasta() -> str:
    try:
        from tkinter import filedialog, Tk

        raiz = Tk()
        raiz.withdraw()
        return filedialog.askdirectory(title="Selecione a pasta das propostas")
    except Exception:
        return input("Caminho da pasta das propostas: ").strip().strip('"')


def main() -> None:
    caminho = sys.argv[1] if len(sys.argv) > 1 else escolher_pasta()
    if not caminho:
        print("Nenhuma pasta selecionada.")
        return

    base = Path(caminho)
    if not base.is_dir():
        print(f"Pasta não encontrada: {base}")
        return

    print(f"Lendo propostas em {base}\n")
    propostas = processar(base)
    if not propostas:
        print("Nenhuma subpasta de proposta encontrada.")
        return

    nome = f"propostas_{datetime.now():%Y%m%d_%H%M}.json"
    salvar(propostas, base.parent / nome)


if __name__ == "__main__":
    main()
